from absl import flags
import mlxu
import json
from .runner_fns import get_runner_fn
from .runner_utils import *

flags.DEFINE_string("config", None, "Path to config file")
flags.DEFINE_string("runner_fn", None, "custom_eval")


FLAGS = flags.FLAGS


def config_from_json():
    with open(FLAGS.config, "r") as f:
        return json.load(f)


def run_fot(_):
    def post_override_callback():
        add_time_to_workdir()
        if hasattr(FLAGS, "logger_dir"):
            FLAGS.logger_dir = FLAGS.workdir

    config_dict = config_from_json()

    if FLAGS.runner_fn is None:
        FLAGS.runner_fn = config_dict["runner_fn"]

    runner_fn = get_runner_fn(FLAGS.runner_fn)

    return run_from_dict(
        main_fn=runner_fn,
        config_dict=config_dict,
        post_override_callback=post_override_callback,
    )


if __name__ == "__main__":
    mlxu.run(run_fot)
