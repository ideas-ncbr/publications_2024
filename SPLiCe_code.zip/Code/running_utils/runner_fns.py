from absl import flags







FLAGS = flags.FLAGS
def get_runner_fn(fn_name):
    if fn_name == "custom_eval":
        from src.evals.custom.eval import main as custom_eval_main
        return custom_eval_main
    elif fn_name == "merge_datasets":
        from src.prepare_data.basic_data_ops.merge_datasets import main as merge_datasets
        return merge_datasets
    elif fn_name == "split_dataset":
        from src.prepare_data.basic_data_ops.split_dataset import main as split_dataset
        return split_dataset
    elif fn_name == "parquet_sample":
        from src.prepare_data.basic_data_ops.parquet_sample import main as parquet_sample
        return parquet_sample
    elif fn_name == "splice_main":
        from src.prepare_data.splice.splice_main import main as splice_main
        return splice_main
    elif fn_name == "count_tokens":
        from src.prepare_data.basic_data_ops.count_tokens import main as count_tokens
        return count_tokens
    elif fn_name == "splice_mixture":
        from src.prepare_data.splice.splice_mixture import main as splice_mixture
        return splice_mixture
    elif fn_name == "hf_to_jsonl":
        from src.prepare_data.basic_data_ops.hf_to_jsonl import main as hf_to_jsonl
        return hf_to_jsonl