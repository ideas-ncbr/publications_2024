# SPLiCe
This repository contains the SPLiCe code that was used in the paper: "Structured Packing in LLM Training Improves Long Context Utilization".  


## Data Preparation
SPLiCe is a data preparation method. In this section, we describe the SPLiCe code.
* [configs/](configs/) - directory with example configs
* [running_utils/runner.py](running_utils/runner.py) - take two arguments
    + `--runner_fn` - procedure to run. Possible procedures are
        - `hf_to_jsonl` - download a dataset from HuggingFace and save it as JSONL file
        - `merge_datasets` - dataset merging
        - `split_dataset` - splitting dataset to chunks
        - `splice_mixture` - prepare SPLiCe mixture
    + `--config` - path to procedure JSON config
    One can also skip `runner_fn` argument and provide it in the config file


* [running_utils/runner_fns.py](running_utils/runner_fns.py) - contains list of procedures that can be run with  running_utils/runner.py
* [src/](src/) - directory with the main code
    + [src/utils/](src/utils/) - experiment utils (handling of logging and parameters)
    + [src/evals/](src/evals/) - code used in our evaluations, in addition to this we have also utilized the [lm-eval harness evaluator](https://github.com/EleutherAI/lm-evaluation-harness) and [Needle In A Haystack evaluator](https://github.com/gkamradt/LLMTest_NeedleInAHaystack). Note that the [src/evals/structured_prompting](src/evals/structured_prompting) part is adopted from [Structured Prompting: Scaling In-Context Learning to 1,000 Examples](https://github.com/sunyt32/structured-prompting?tab=readme-ov-file)
        - [src/evals/custom/lost_in_the_middle/data/](src/evals/custom/lost_in_the_middle/data/) contains evaluation data downloaded and saved in a proper format from [Lost in the Middle: How Language Models Use Long Contexts](https://github.com/nelson-liu/lost-in-the-middle.git) 
    + [src/prepare_data/](src/prepare_data) repository
        - [src/prepare_data/basic_data_ops/](src/prepare_data/basic_data_ops/) - code for downloading datasets from hf, shuffling, merging and splitting the data, calculate statistics.
        - [src/prepare_data/utils/](src/prepare_data/utils) - code for handling JSONL files
        - [src/prepare_data/splice/](src/prepare_data/splice/) - SPLiCe related code
            + [src/prepare_data/splice/splice_main.py](src/prepare_data/splice/splice_main.py) - main code for splice is located in `aggregate_docs` procedure
            + [src/prepare_data/splice/splice_mixture.py](src/prepare_data/splice/splice_mixture.py) - code for creating a mixture in one run (prepare data with splice, merge with RedPajama, shuffle)
            + [src/prepare_data/splice/stats.py](src/prepare_data/splice/stats.py) - for calculation of SPLiCe stats (num repositories/files in one training sample)
            + [src/prepare_data/splice/retrievers/](src/prepare_data/splice/retrievers/) - implementation of retrievers for SPLiCe, For bm25 we use the [retriv](https://github.com/AmenRa/retriv). If you want to use bm25 please copy [retriv](https://github.com/AmenRa/retriv) to `src/prepare_data/`. We note that this is not our repository.
        

 ## Running SPLiCe
 This instruction summarizes how to run a sample SPLiCe pipeline on Ubuntu with `python3` and `pip`

1. Create a virtual env `python3 -m venv env`
2. Activate the env `source env/bin/activate`
3. Install requirements `pip3 install -r requirements.txt`
4. Clone retriv `cd src/prepare_data/; git clone https://github.com/AmenRa/retriv.git; cd ../..`
4. Run example SPLiCe data preparation on example data [assets/sample_data_3.jsonl](assets/sample_data_3.jsonl)
    + with repo `python3 -m running_utils.runner --config configs/splice_example_repo.json`  
    the result will be saved in [assets/tmp/splice_test_output.repo.jsonl](assets/tmp/splice_test_output.repo.jsonl)
    + with bm25 `python3 -m running_utils.runner --config configs/splice_example_bm25.json`  
    the result will be saved in [assets/tmp/splice_test_output.bm25.jsonl](assets/tmp/splice_test_output.bm25.jsonl)





## Training
For the training, we utilize a modified version of [EasyLM](https://github.com/young-geng/EasyLM) provided by FoT authors as [LongLLama](https://github.com/CStanKonrad/long_llama).
We utilized their modified version because it supports  FoT context extension method along with CodeLlama and Naive.



