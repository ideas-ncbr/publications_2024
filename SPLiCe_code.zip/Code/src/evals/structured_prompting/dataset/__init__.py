from .AGNews import AGNews
from .ARCC import ARCC
from .ARCE import ARCE
from .BaseTask import BaseTask
from .BoolQ import BoolQ
from .CB import CB
from .COPA import COPA
from .DBPedia import DBPedia
from .HellaSwag import HellaSwag
from .MR import MR
from .MultiRC import MultiRC
from .OBQA import OBQA
from .open_ended_qa import COQA, NQ, SQuAD, SQuADv2, TriviaQA, WebQS
from .PIQA import PIQA
from .RTE import RTE
from .SST2 import SST2
from .SST5 import SST5
from .StoryCloze import StoryCloze
from .Subj import Subj
from .TREC import TREC
from .WiC import WiC
from .Winogrande import Winogrande
from .WSC import WSC

dataset_dict = {
    "cb": CB,
    "copa": COPA,
    "sst2": SST2,
    "rte": RTE,
    "agnews": AGNews,
    "sst5": SST5,
    "subj": Subj,
    "trec": TREC,
    "arcc": ARCC,
    "arce": ARCE,
    "dbpedia": DBPedia,
    "hellaswag": HellaSwag,
    "mr": MR,
    "obqa": OBQA,
    "piqa": PIQA,
    "storycloze": StoryCloze,
    "winogrande": Winogrande,
    "boolq": BoolQ,
    "wic": WiC,
    "wsc": WSC,
    "multirc": MultiRC,
    "nq": NQ,
    "webqs": WebQS,
    "triviaqa": TriviaQA,
    "squad": SQuAD,
    "squadv2": SQuADv2,
    "coqa": COQA,
}


def get_dataset(dataset, *args, **kwargs) -> BaseTask:
    return dataset_dict[dataset](*args, **kwargs)
