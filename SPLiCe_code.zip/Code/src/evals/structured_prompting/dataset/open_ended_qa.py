from datasets import load_dataset

from .BaseTask import BaseTask


# open-ended QA
class NQ(BaseTask):
    def __init__(self, *args, is_train=True, **kwargs):
        super().__init__(*args, **kwargs)
        dataset = load_dataset("nq_open")
        self.dataset = dataset["train"] if is_train else dataset["validation"]
        self.templates = self.templates_set_without_newline()
        self.class_num = 1
        self.preprocess_dataset()

    def templates_set_without_newline(self):
        return [("Question: {question}? Answer:", " {answer}")]

    def preprocess_example(self, example):
        input_temp, output_temp = self.templates[self.temp_index]
        input_str = input_temp.replace("{question}", example["question"])
        input_str = [input_str] * self.class_num
        answer_str = [
            output_temp.replace("{answer}", answer) for answer in example["answer"]
        ]
        return input_str, answer_str, -1


class WebQS(BaseTask):
    def __init__(self, *args, is_train=True, **kwargs):
        super().__init__(*args, **kwargs)
        dataset = load_dataset("web_questions")
        self.dataset = dataset["train"] if is_train else dataset["test"]
        self.templates = self.templates_set_without_newline()
        self.class_num = 1
        self.preprocess_dataset()

    def templates_set_without_newline(self):
        return [("Question: {question} Answer:", " {answer}")]

    def preprocess_example(self, example):
        input_temp, output_temp = self.templates[self.temp_index]
        input_str = input_temp.replace("{question}", example["question"])
        input_str = [input_str] * self.class_num
        answer_str = [
            output_temp.replace("{answer}", answer) for answer in example["answers"]
        ]
        return input_str, answer_str, -1


class TriviaQA(BaseTask):
    def __init__(self, *args, is_train=True, **kwargs):
        super().__init__(*args, **kwargs)
        dataset = load_dataset("trivia_qa", "rc.nocontext")
        self.dataset = dataset["train"] if is_train else dataset["validation"]
        self.templates = self.templates_set_without_newline()
        self.class_num = 1
        self.preprocess_dataset()

    def templates_set_without_newline(self):
        return [("Question: {question} Answer:", " {answer}")]

    def preprocess_example(self, example):
        input_temp, output_temp = self.templates[self.temp_index]
        input_str = input_temp.replace("{question}", example["question"])
        input_str = [input_str] * self.class_num
        answer_str = [
            output_temp.replace("{answer}", answer)
            for answer in example["answer"]["aliases"]
        ]
        return input_str, answer_str, -1


class SQuADv2(BaseTask):
    def __init__(self, *args, is_train=True, **kwargs):
        super().__init__(*args, **kwargs)
        dataset = load_dataset("squad_v2")
        self.dataset = dataset["train"] if is_train else dataset["validation"]
        self.templates = self.templates_set_without_newline()
        self.class_num = 1
        self.preprocess_dataset()

    def templates_set_without_newline(self):
        return [("Passage: {context} Question: {question} Answer:", " {answer}")]

    def preprocess_example(self, example):
        input_temp, output_temp = self.templates[self.temp_index]
        input_str = input_temp.replace("{question}", example["question"]).replace(
            "{context}", example["context"]
        )
        input_str = [input_str] * self.class_num

        if len(example["answers"]["text"]) > 0:
            answer_str = [
                output_temp.replace("{answer}", answer)
                for answer in example["answers"]["text"]
            ]
        else:
            answer_str = [output_temp.replace("{answer}", "none")]
        return input_str, answer_str, -1


class SQuAD(BaseTask):
    def __init__(self, *args, is_train=True, **kwargs):
        super().__init__(*args, **kwargs)
        dataset = load_dataset("squad")
        self.dataset = dataset["train"] if is_train else dataset["validation"]
        self.templates = self.templates_set_without_newline()
        self.class_num = 1
        self.preprocess_dataset()

    def templates_set_without_newline(self):
        return [("Passage: {context} Question: {question} Answer:", " {answer}")]

    def preprocess_example(self, example):
        input_temp, output_temp = self.templates[self.temp_index]
        input_str = input_temp.replace("{question}", example["question"]).replace(
            "{context}", example["context"]
        )
        input_str = [input_str] * self.class_num

        if len(example["answers"]["text"]) > 0:
            answer_str = [
                output_temp.replace("{answer}", answer)
                for answer in example["answers"]["text"]
            ]
        else:
            answer_str = [output_temp.replace("{answer}", "none")]
        return input_str, answer_str, -1


class COQA(BaseTask):
    def __init__(self, *args, is_train=True, **kwargs):
        super().__init__(*args, **kwargs)
        dataset = load_dataset("Zaid/coqa_expanded")
        self.dataset = dataset["train"] if is_train else dataset["validation"]
        self.templates = self.templates_set_without_newline()
        self.class_num = 1
        self.preprocess_dataset()

    def templates_set_without_newline(self):
        return [("Passage: {story} Question: {question} Answer:", " {answer}")]

    def preprocess_example(self, example):
        input_temp, output_temp = self.templates[self.temp_index]
        input_str = input_temp.replace("{question}", example["question"]).replace(
            "{story}", example["story"]
        )
        input_str = [input_str] * self.class_num

        if len(example["answer"]["input_text"]) > 0:
            answer_str = [
                output_temp.replace("{answer}", example["answer"]["input_text"])
            ]
        else:
            answer_str = [output_temp.replace("{answer}", "none")]
        return input_str, answer_str, -1
