from typing import Any
from ..custom_task import CustomTask
from xopen import xopen
import json
import copy
import random
import numpy as np

DOC_FORMAT = "Document [{doc_id}](Title: {doc_title}) {doc_text}"
QA_PROMPT_FORMAT = """Write a high-quality answer for the given question using only the provided search results (some of which might be irrelevant).

{search_results}

Question: {question}
Answer:"""

KV_PROMPT_FORMAT = """Extract the value corresponding to the specified key in the JSON object below.

JSON data:
{formatted_kv_records}
 "{key}":"""


def prepare_data_qa(
    path_to_data: str, gt_position: int, doc_format: str, prompt_format: str, seed: int
):
    result = []
    with xopen(path_to_data, "r") as file:
        for rec_id, raw_record in enumerate(file):
            record = json.loads(raw_record)

            other_docs = []
            gold_doc = None
            for d in record["ctxs"]:
                if d["isgold"]:
                    assert gold_doc is None
                    gold_doc = d
                else:
                    other_docs.append(d)

            assert gold_doc is not None
            if seed != -1:
                perm = np.random.RandomState(seed=seed + rec_id).permutation(
                    len(other_docs)
                )
                other_docs = [other_docs[i.item()] for i in perm]

            all_docs = copy.deepcopy(other_docs)
            all_docs.insert(gt_position, gold_doc)

            str_docs = []
            for i, d in enumerate(all_docs):
                str_docs.append(
                    doc_format.format(
                        doc_id=i + 1, doc_title=d["title"], doc_text=d["text"]
                    )
                )

            str_docs = "\n".join(str_docs)

            question = record["question"]
            input = prompt_format.format(question=question, search_results=str_docs)
            answers = record["nq_annotated_gold"]["short_answers"]
            result.append((input, answers))

    return result


def prepare_data_kv(path_to_data: str, gt_position: int, prompt_format: str, seed: int):
    result = []
    with xopen(path_to_data, "r") as file:
        for raw_record in file:
            record = json.loads(raw_record)

            gt_kv = record["key"], record["value"]

            other_kv = []
            for k, v in record["ordered_kv_records"]:
                if k != gt_kv[0]:
                    other_kv.append((k, v))
            all_kv = copy.deepcopy(other_kv)

            all_kv.insert(gt_position, gt_kv)

            json_parts = []
            for k, v in all_kv:
                json_parts.append(f'"{k}": "{v}"')

            formatted_kv_records = "{" + ",\n ".join(json_parts) + "}"

            input = prompt_format.format(
                formatted_kv_records=formatted_kv_records, key=gt_kv[0]
            )
            output = f'"{gt_kv[1]}"'

            result.append((input, output))

    if seed != -1:
        rnd_state = random.getstate()
        random.seed(seed)
        random.shuffle(result)
        random.setstate(rnd_state)

    return result


class LitMDocs(CustomTask):
    def __init__(
        self,
        seed,
        max_samples,
        path_to_data,
        gt_position,
        doc_format=DOC_FORMAT,
        prompt_format=QA_PROMPT_FORMAT,
    ) -> None:
        super().__init__(seed, max_samples)

        self.data = prepare_data_qa(
            path_to_data=path_to_data,
            gt_position=gt_position,
            doc_format=doc_format,
            prompt_format=prompt_format,
            seed=seed,
        )

    def __iter__(self):
        for i, (input, outputs) in enumerate(self.data):
            if i >= self.max_samples:
                return None
            else:
                yield input, outputs


class LitMKV(CustomTask):
    def __init__(
        self,
        seed,
        max_samples,
        path_to_data: str,
        gt_position: int,
        prompt_format=KV_PROMPT_FORMAT,
    ) -> None:
        super().__init__(seed, max_samples)

        self.data = prepare_data_kv(
            path_to_data=path_to_data,
            gt_position=gt_position,
            prompt_format=prompt_format,
            seed=seed,
        )

    def __iter__(self):
        for i, (input, output) in enumerate(self.data):
            if i >= self.max_samples:
                return None
            else:
                yield input, output
