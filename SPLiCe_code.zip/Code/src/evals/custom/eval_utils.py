from transformers import PreTrainedModel, PreTrainedTokenizer
import torch
import re
from absl import flags, app
import logging
import sys
import numpy as np
from typing import List, Dict, Any, Tuple, Optional, Union
from .custom_task import CustomTask
from ...utils.debug import (
    debug_inputs,
    debug_outputs,
    should_debug_outputs,
    should_debug_inputs,
    debug_stats,
    should_debug_stats,
)

LOGGER = logging.Logger("Data Processing", level=logging.INFO)
LOGGER_HANDLER = logging.StreamHandler(sys.stderr)
LOGGER_HANDLER.setFormatter(
    logging.Formatter("[%(asctime)s] Fine-Tuning [%(levelname)s] : %(message)s")
)
LOGGER.addHandler(LOGGER_HANDLER)


def detokenize_skip_zero(tokens, tokenizer):
    return tokenizer.decode(tokens).replace(tokenizer.decode([0]), "")


@torch.no_grad()
def forward_eval(
    model: PreTrainedModel,
    input_tokens: np.array,
    answer_mask: np.array,
    input_mask: np.array = None,
    tokenizer: PreTrainedTokenizer = None,
):
    """
    Does forward pass and checks whether the tokens for the
    correct answer are the most probable ones.
    input_tokens of shape [BATCH, INPUT_LENGTH]
        contains both input and answer
        answer_mask points to the answer part
        input_mask denotes whats is hidde (example padding)
    answer_mask of shape [BATCH, INPUT_LENGTH]
        0 - denotes input
        1 - denotes answer
    input_mask of shape [BATCH, INPUT_LENGTH]
        0 - denotes hidden from the model
        1 - denotes shown to the model
    """
    input_tokens = torch.from_numpy(input_tokens).to(torch.long).to(model.device)
    answer_mask = torch.from_numpy(answer_mask).to(model.device)
    input_mask = (
        torch.from_numpy(input_mask).to(model.device)
        if input_mask is not None
        else torch.ones_like(input_tokens)
    )

    outputs = model(input_ids=input_tokens, attention_mask=input_mask, use_cache=False)
    logits = outputs.logits

    model_ans = torch.argmax(logits, dim=-1)
    assert model_ans.shape == input_tokens.shape
    assert answer_mask.shape == input_tokens.shape

    if tokenizer is not None and should_debug_outputs():
        debug_outputs(
            f"Model answered:\n"
            f"  raw: {(model_ans[:, :-1] *  answer_mask[:, 1:])[0]}\n"
            f"  detokenized:{detokenize_skip_zero((model_ans[:, :-1] *  answer_mask[:, 1:])[0], tokenizer)}\n"
            f"Expected answer is:\n"
            f"  raw: {(input_tokens[:, 1:] * answer_mask[:, 1:])[0]}\n"
            f"  detokenized:{detokenize_skip_zero((input_tokens[:, 1:] * answer_mask[:, 1:])[0], tokenizer)}\n"
        )

    correct = (
        ((model_ans[:, :-1] == input_tokens[:, 1:]) * answer_mask[:, 1:])
        .sum(dim=-1)
        .cpu()
    )
    total = answer_mask.sum(dim=-1).cpu()

    results = []
    for seq_acc, token_acc in zip(correct == total, correct / total):
        results.append(
            {
                "seq_acc": float(seq_acc.item()),
                "token_acc": float(token_acc.item()),
            }
        )

    del outputs
    del correct
    del total
    del input_tokens
    del answer_mask
    del input_mask

    return results


@torch.no_grad()
def perplexity_eval(
    model: PreTrainedModel,
    input_tokens: np.array,
    answer_mask: np.array,
    input_mask: np.array = None,
):
    input_tokens = torch.from_numpy(input_tokens).to(model.device)
    answer_mask = torch.from_numpy(answer_mask).to(model.device)
    input_mask = (
        torch.from_numpy(input_mask).to(model.device)
        if input_mask is not None
        else torch.ones_like(input_tokens)
    )

    outputs = model(input_ids=input_tokens, attention_mask=input_mask, use_cache=False)
    logits = outputs.logits
    assert len(logits.shape) == 3

    logits = torch.nn.functional.log_softmax(logits[:, :-1], dim=-1)
    loss = (
        logits[
            torch.arange(input_tokens.shape[0]).reshape(-1, 1),
            torch.arange(input_tokens.shape[1] - 1).reshape(1, -1),
            input_tokens[:, 1:],
        ]
        * answer_mask[:, 1:]
    )
    loss = (
        -loss.sum(dim=-1)
        / torch.maximum(
            answer_mask[:, 1:].sum(dim=-1),
            torch.tensor([1.0], device=answer_mask.device),
        )
    ).cpu()

    results = []

    for l in loss:
        results.append(
            {"loss": float(l.item()), "perplexity": float(torch.exp(l).item())}
        )

    del outputs
    del input_tokens
    del answer_mask
    del input_mask

    return results


@torch.no_grad()
def gen_eval(
    model: PreTrainedModel,
    prefix_tokens: np.array,
    prefix_mask: np.array,
    answer_tokens: np.array,
    answer_mask: np.array,
    num_beams: int,
    gen_logits_processor,
):
    """
    Similar to the forward_eval but performs generation.
    prefix_tokens - shape [BATCH, INPUT_LENGTH]
    prefix_mask - shape [BATCH, INPUT_LENGTH]
    answer_tokens - shape [BATCH, OUTPUT_LENGTH]
    answer_mask - shape [BATCH, OUTPUT_LENGTH]
    """
    prefix_tokens = torch.from_numpy(prefix_tokens).to(model.device)
    prefix_mask = torch.from_numpy(prefix_mask).to(model.device)
    answer_tokens = torch.from_numpy(answer_tokens).to(model.device)
    answer_mask = torch.from_numpy(answer_mask).to(model.device)

    assert prefix_tokens.shape == prefix_mask.shape
    assert answer_tokens.shape == answer_mask.shape

    model_ans = model.generate(
        input_ids=prefix_tokens,
        attention_mask=prefix_mask,
        max_new_tokens=answer_tokens.shape[-1],
        num_beams=num_beams,
        logits_processor=gen_logits_processor,
    )
    model_ans = model_ans[:, -answer_tokens.shape[-1] :]
    assert model_ans.shape == answer_tokens.shape

    correct = ((model_ans == answer_tokens) * answer_mask).sum(-1)
    total = answer_mask.sum(-1)

    results = []
    for seq_acc, token_acc in zip(correct == total, correct / total):
        results.append(
            {
                "seq_acc": float(seq_acc.item()),
                "token_acc": float(token_acc.item()),
            }
        )

    return results


@torch.no_grad()
def gen_match_eval(
    model: PreTrainedModel,
    prefix_tokens: np.array,
    prefix_mask: np.array,
    answer_text: Union[str, List[str]],
    max_new_tokens: int,
    tokenizer: PreTrainedTokenizer,
    grader,
    gen_logits_processor,
):
    """
    Similar to gen_eval but expects input to have batch dim equal to 1.
    Uses regex to match the output.
    """

    assert max_new_tokens is not None
    prefix_tokens = torch.from_numpy(prefix_tokens).to(model.device)
    prefix_mask = torch.from_numpy(prefix_mask).to(model.device)

    assert prefix_tokens.shape == prefix_mask.shape

    model_ans = model.generate(
        input_ids=prefix_tokens,
        attention_mask=prefix_mask,
        max_new_tokens=max_new_tokens,
        num_beams=1,
        logits_processor=gen_logits_processor,
    )
    model_ans = model_ans[:, prefix_tokens.shape[-1] :]
    model_ans = model_ans.cpu()
    model_ans_txt = tokenizer.batch_decode(model_ans, skip_special_tokens=True)
    results = []
    assert len(model_ans) == len(answer_text)
    for per_example_model_answer, per_example_at in zip(model_ans_txt, answer_text):
        if isinstance(per_example_at, str):
            per_example_at = [per_example_at]
        assert isinstance(per_example_at, list) or isinstance(per_example_at, tuple)

        grade_list = [
            grader.grade(prediction=per_example_model_answer, ground_truth=gt)
            for gt in per_example_at
        ]
        grade = grader.aggregate(grade_list)
        if should_debug_outputs():
            debug_outputs(
                f"model raw answer: {per_example_model_answer} expected:{per_example_at}, grades: {grade_list}->{grade} input has shape {prefix_tokens.shape}, output has shape {model_ans.shape} {model_ans}"
            )
        results.append(
            {
                **grade,
                "$text": {
                    "raw_model_ans": per_example_model_answer,
                    "gt_answers": per_example_at,
                },
            }
        )

    return results


def process_results(results_list: List[Dict[str, Any]]):
    combined = {}
    for result in results_list:
        for k, v in result.items():
            if k == "$text":
                pass
            elif k in combined:
                combined[k].append(v)
            else:
                combined[k] = [v]

    final_results = {}
    for k, v in combined.items():
        final_results[f"{k}_mean"] = np.mean(v).item()
        final_results[f"{k}_std"] = np.std(v).item()
        final_results[f"{k}_min"] = np.min(v).item()
        final_results[f"{k}_max"] = np.max(v).item()
        final_results[f"{k}_nsamples"] = len(v)

    return final_results


def front_truncate_to_context(
    input: np.array,
    max_length: Optional[int],
    pad_right_to: Tuple[Optional[int], Optional[int]] = (None, 0),
    tokenizer: Optional[PreTrainedTokenizer] = None,
):
    """
    tokens: [BATCH, SEQ_LEN]
    """
    assert len(input.shape) == 2
    if max_length is not None:
        result = input[:, -max_length:]
    else:
        result = input

    if pad_right_to[0] is not None:
        pad_size = pad_right_to[0] - result.shape[-1]
        assert pad_size >= 0
        result = np.pad(
            result,
            ((0, 0), (0, pad_size)),
            mode="constant",
            constant_values=pad_right_to[1],
        )

    if should_debug_inputs() and (
        max_length is not None or pad_right_to[0] is not None
    ):
        debug_inputs_str = (
            f"Inputs truncated/padded from {input.shape[-1]} to {result.shape[-1]}:\n"
            f"new_inputs:{result}\n"
        )
        if tokenizer is not None:
            debug_inputs_str += (
                f"detokenized:{detokenize_skip_zero(result[0], tokenizer)}"
            )
        debug_inputs(debug_inputs_str)
    if should_debug_stats() and (max_length is not None or pad_right_to[0] is not None):
        debug_stats_str = (
            f"Inputs truncated/padded from {input.shape[-1]} to {result.shape[-1]}:\n"
        )
        debug_stats(debug_stats_str)

    return result


class InputBatcher:
    def __init__(
        self,
        dataset: CustomTask,
        batch_size: int,
        prefix_tokenizer: PreTrainedTokenizer,
        suffix_tokenizer: PreTrainedTokenizer,
        skip_last: bool = False,
        example_separator=" \n ",
        pad_input_left=True,
        pad_answer_right=True,
    ) -> None:
        self.dataset = dataset
        self.batch_size = batch_size
        self.prefix_tokenizer = prefix_tokenizer
        self.suffix_tokenizer = suffix_tokenizer
        self.examples = self.dataset.get_examples()
        self.skip_last = skip_last
        self.example_separator = example_separator
        self.pad_input_left = pad_input_left
        self.pad_answer_right = pad_answer_right

    def __iter__(self):
        def pad_inputs(input_text_list, pad_left):
            input_list = [x[0] for x in input_text_list]
            text_list = [x[1] for x in input_text_list]
            max_length = max([x["input_ids"].shape[-1] for x in input_list])
            padded_inputs = []
            padded_masks = []
            for xm in input_list:
                x = xm["input_ids"].astype(np.int32)
                x_mask = xm["attention_mask"]

                assert len(x.shape) == 2 and len(x_mask.shape) == 2
                assert x.shape[0] == 1 and x_mask.shape[0] == 1

                if pad_left:
                    pl, pr = max_length - x.shape[-1], 0
                else:
                    pl, pr = 0, max_length - x.shape[-1]
                x = np.pad(
                    x, ((0, 0), (pl, pr)), mode="constant", constant_values=0
                )  # TODO pad token id
                x_mask = np.pad(
                    x_mask, ((0, 0), (pl, pr)), mode="constant", constant_values=0
                )

                padded_inputs.append(x)
                padded_masks.append(x_mask)

            padded_inputs = np.concatenate(padded_inputs, axis=0)
            padded_masks = np.concatenate(padded_masks, axis=0)

            assert padded_inputs.shape[0] == padded_masks.shape[0]

            return (padded_inputs, padded_masks), text_list

        all_ex_tokens = []
        all_ex_mask = []
        if self.examples is not None:

            def prepare_example(example, prefix_tokenizer, suffix_tokenizer):
                input_str, answer_str = example
                input_tokenized = prefix_tokenizer(
                    input_str, return_tensors="np", padding=False
                )
                answer_tokenized = suffix_tokenizer(
                    answer_str, return_tensors="np", padding=False
                )
                separator = suffix_tokenizer(
                    self.example_separator, return_tensors="np", padding=False
                )
                return np.concatenate(
                    [
                        input_tokenized["input_ids"],
                        answer_tokenized["input_ids"],
                        separator["input_ids"],
                    ],
                    axis=-1,
                ), np.concatenate(
                    [
                        input_tokenized["attention_mask"],
                        answer_tokenized["attention_mask"],
                        separator["attention_mask"],
                    ],
                    axis=-1,
                )

            fst_tokens, fst_mask = prepare_example(
                self.examples[0], self.prefix_tokenizer, self.suffix_tokenizer
            )
            all_ex_tokens.append(fst_tokens)
            all_ex_mask.append(fst_mask)
            for example in self.examples[1:]:
                tokens, mask = prepare_example(
                    example, self.suffix_tokenizer, self.suffix_tokenizer
                )
                all_ex_tokens.append(tokens)
                all_ex_mask.append(mask)

        example_tokens = (
            np.concatenate(all_ex_tokens, axis=-1) if len(all_ex_tokens) > 0 else None
        )
        example_mask = (
            np.concatenate(all_ex_mask, axis=-1) if len(all_ex_mask) > 0 else None
        )

        if example_tokens is not None:
            if should_debug_inputs():
                debug_inputs(
                    f"Prepared {len(all_ex_tokens)} few-shot examples:\n"
                    f"tokens:{example_tokens}\n"
                    f"attention_mask:{example_mask}\n"
                    f"detokenized:{self.suffix_tokenizer.decode(example_tokens[0])}\n"
                )

        generator = iter(self.dataset)
        batch_inputs = []
        batch_answers = []
        prefix_tokenizer = (
            self.prefix_tokenizer if example_tokens is None else self.suffix_tokenizer
        )
        suffix_tokenizer = self.suffix_tokenizer

        for input_txt, answer_txt in generator:
            if should_debug_inputs():
                debug_inputs(
                    "Adding to batch the following pair (raw_text):\n"
                    f"input:{input_txt}\n"
                    f"answer:{answer_txt}\n"
                )
            new_input = prefix_tokenizer(input_txt, return_tensors="np", padding=False)

            if isinstance(answer_txt, list) or isinstance(answer_txt, tuple):
                # many answers
                new_ans = None
                for ans in answer_txt:
                    assert isinstance(ans, str)
                    # pick the longest for input truncation
                    ans_tok = suffix_tokenizer(ans, return_tensors="np", padding=False)
                    if (
                        new_ans is None
                        or new_ans["input_ids"].shape[-1]
                        < ans_tok["input_ids"].shape[-1]
                    ):
                        new_ans = ans_tok
            else:
                assert isinstance(answer_txt, str)
                new_ans = suffix_tokenizer(
                    answer_txt, return_tensors="np", padding=False
                )
            if should_debug_inputs():
                debug_inputs(
                    "Adding to batch the following pair (tokenized):\n"
                    f"input:{new_input}\n"
                    f"answer:{new_ans}\n"
                )

            if example_tokens is not None:
                new_input = {
                    "input_ids": np.concatenate(
                        [example_tokens, new_input["input_ids"]], axis=-1
                    ),
                    "attention_mask": np.concatenate(
                        [example_mask, new_input["attention_mask"]], axis=-1
                    ),
                }
                if should_debug_inputs():
                    debug_inputs(
                        "Extending the tokenized input with few shot examples:\n"
                        f"dict:{new_input}\n"
                        f"text:{suffix_tokenizer.decode(new_input['input_ids'][0])}\n"
                    )

            batch_inputs.append((new_input, input_txt))
            batch_answers.append((new_ans, answer_txt))

            if len(batch_inputs) >= self.batch_size:
                assert len(batch_inputs) == self.batch_size
                yield pad_inputs(
                    batch_inputs, pad_left=self.pad_input_left
                ), pad_inputs(batch_answers, pad_left=not self.pad_answer_right)
                batch_inputs = []
                batch_answers = []

        if len(batch_inputs) > 0 and not self.skip_last:
            yield pad_inputs(batch_inputs, pad_left=self.pad_input_left), pad_inputs(
                batch_answers, pad_left=not self.pad_answer_right
            )
            batch_inputs = []
            batch_answers = []
