class CustomTask:
    def __init__(self, seed, max_samples) -> None:
        self.max_samples = max_samples
        self.seed = seed

    def get_examples(self):
        """
        Get few shot examples.
        """
        return None

    def __iter__(self):
        """
        Iterate throughout and yield pairs (input_str, answer_str)
        """
        pass

