from .custom_task import CustomTask
from datasets import load_dataset
import numpy as np


def process_record(record):
    docs_formated = []
    for title, sentences in zip(
        record["context"]["title"], record["context"]["sentences"]
    ):
        doc = f"{title}:\n{' '.join(sentences)}"
        docs_formated.append(doc)

    docs_formated = "\n".join(docs_formated)

    prompt = f"""{docs_formated}

Question: {record['question']}
Answer:"""
    return prompt, record["answer"]


class HotPotQA(CustomTask):
    def __init__(self, seed, max_samples, num_shots, mode="fullwiki") -> None:
        super().__init__(seed, max_samples)

        self.mode = mode
        self.data = load_dataset(
            "hotpot_qa", mode, split="validation"
        )  # no answers for test set
        rnd_state = np.random.get_state()
        self.seed = seed
        np.random.seed(seed)
        self.permutation = np.random.permutation(len(self.data))[:max_samples]
        np.random.set_state(rnd_state)

        self.num_shots = num_shots

    def get_examples(self):
        train_data = load_dataset("hotpot_qa", self.mode, split="train")
        train_data = [td for td in train_data]
        permutation = np.random.RandomState(seed=self.seed + 1).permutation(
            len(train_data)
        )

        examples_records = [train_data[i.item()] for i in permutation[: self.num_shots]]

        examples = []
        for er in examples_records:
            input_ans = process_record(er)
            examples.append(input_ans)

        return examples

    def __iter__(self):
        for rid in self.permutation:
            record = self.data[rid.item()]
            input, answer = process_record(record)
            yield input, answer
