from ..structured_prompting.dataset import get_dataset
from ..structured_prompting.utils.functional import setup_seed
from .custom_task import CustomTask
import random


class StructuredPromptingTask(CustomTask):
    def __init__(
        self, seed, max_samples, num_shots, ds_name=None, lstrip_answers=True
    ) -> None:
        super().__init__(seed, max_samples)
        self.num_shots = num_shots
        assert ds_name is not None
        self.ds_name = ds_name
        setup_seed(seed)
        self.lstrip_answers = lstrip_answers

    def strip_answer(self, answer):
        if self.lstrip_answers:
            return answer.lstrip()
        else:
            return answer

    def get_examples(self):
        train_data = get_dataset(self.ds_name, is_train=True)
        examples = []

        train_data = [td for td in train_data]
        rnd_state = random.getstate()
        random.seed(self.seed)
        random.shuffle(train_data)
        random.setstate(rnd_state)

        for input_str, output, answer in train_data:
            if answer == -1:
                answer = output
            else:
                answer = output[answer]
            examples.append((input_str, self.strip_answer(answer)))
            if len(examples) >= self.num_shots:
                break

        if len(examples) != self.num_shots:
            raise ValueError("No enough examples in the dataset")

        return examples

    def __iter__(self):
        eval_data = get_dataset(self.ds_name, is_train=False)

        eval_data = [ed for ed in eval_data]
        rnd_state = random.getstate()
        random.seed(self.seed)
        random.shuffle(eval_data)
        random.setstate(rnd_state)
        eval_data = eval_data[: self.max_samples]

        for input_str, output, answer in eval_data:
            if answer == -1:
                answer = output
            else:
                answer = output[answer]

            yield input_str, self.strip_answer(answer)


class WIC(StructuredPromptingTask):
    def __init__(self, seed, max_samples, num_shots) -> None:
        super().__init__(
            seed=seed, max_samples=max_samples, num_shots=num_shots, ds_name="wic"
        )


class SST5(StructuredPromptingTask):
    def __init__(self, seed, max_samples, num_shots) -> None:
        super().__init__(
            seed=seed, max_samples=max_samples, num_shots=num_shots, ds_name="sst5"
        )


class MultiRC(StructuredPromptingTask):
    def __init__(self, seed, max_samples, num_shots) -> None:
        super().__init__(
            seed=seed, max_samples=max_samples, num_shots=num_shots, ds_name="multirc"
        )


class CB(StructuredPromptingTask):
    def __init__(self, seed, max_samples, num_shots) -> None:
        super().__init__(
            seed=seed, max_samples=max_samples, num_shots=num_shots, ds_name="cb"
        )


class DBPedia(StructuredPromptingTask):
    def __init__(self, seed, max_samples, num_shots) -> None:
        super().__init__(
            seed=seed, max_samples=max_samples, num_shots=num_shots, ds_name="dbpedia"
        )


class TRECTask(StructuredPromptingTask):
    def __init__(self, seed, max_samples, num_shots) -> None:
        super().__init__(
            seed=seed, max_samples=max_samples, num_shots=num_shots, ds_name="trec"
        )


class WEBQSTask(StructuredPromptingTask):
    def __init__(self, seed, max_samples, num_shots) -> None:
        super().__init__(
            seed=seed, max_samples=max_samples, num_shots=num_shots, ds_name="webqs"
        )
