from transformers import LogitsProcessor, AutoTokenizer
import torch
from typing import List


class StopAfterWordIsGenerated(LogitsProcessor):

    def __init__(self, stop_words: List[str], tokenizer: AutoTokenizer):
        super().__init__()

        self.stop_words = stop_words
        self.tokenizer = tokenizer
        stop_words_tokenized = tokenizer.encode(
            self.stop_words, return_tensors="np"
        ).tolist()
        assert isinstance(stop_words_tokenized, list) and len(
            stop_words_tokenized
        ) == len(self.stop_words)
        self.longest_stop_word_in_tokens = max(list(map(len, stop_words_tokenized)))

    def __call__(
        self, input_ids: torch.LongTensor, scores: torch.FloatTensor
    ) -> torch.FloatTensor:

        assert len(input_ids.shape) == 2  # Batch, SEQ
        assert len(scores.shape) == 2  # Batch, VOCAB

        suffix = input_ids[:, -(self.longest_stop_word_in_tokens + 4) : -1]
        suffix_txt = self.tokenizer.batch_decode(suffix)
        assert isinstance(suffix_txt, list) and len(suffix_txt) == input_ids.shape[0]
        assert isinstance(suffix_txt[0], str)

        for i, st in enumerate(suffix_txt):
            for sw in self.stop_words:
                if st.endswith(sw):
                    scores[i, :] = float(-1e3)
                    scores[i, self.tokenizer.eos_token_id] = float(1e3)
        return scores
