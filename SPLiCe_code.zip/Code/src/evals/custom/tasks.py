from .landmark import LandmarkTask
from .longchat import LongChatTask
from .structured_prompting import TRECTask, WEBQSTask, DBPedia, CB, MultiRC, SST5, WIC
from .language_modeling import WikiSimple
from .lost_in_the_middle.lost_in_the_middle import LitMDocs, LitMKV
from .hotpotqa import HotPotQA
def get_tasks():
    return {
        "landmark": LandmarkTask,
        "longchat": LongChatTask,
        "trec": TRECTask,
        "webqs": WEBQSTask,
        "dbpedia": DBPedia,
        "cb": CB,
        "multirc": MultiRC,
        "sst5": SST5,
        "wic": WIC,
        "wikipedia_simple": WikiSimple,
        "lost_in_the_middle_docs": LitMDocs,
        "lost_in_the_middle_kv": LitMKV,
        "hot_pot_qa": HotPotQA
    }