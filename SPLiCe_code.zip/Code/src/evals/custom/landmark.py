import numpy as np
from numpy import random
from .custom_task import CustomTask
from absl import flags, app
flags.DEFINE_string("replace_last_words_with", None, "")
FLAGS = flags.FLAGS

#The text above mentions a number, passkey. What is the pass key mentioned in the text above, give only the number? Answer:

# Adopted from https://github.com/epfml/landmark-attention

def generate_prompt_landmark(n_garbage, seed):
    """Generates a text file and inserts an execute line at a random position."""
    rnd_state = random.get_state()
    #print(f"seed: {seed}")
    random.seed(seed)
    n_garbage_prefix = random.randint(0, n_garbage)
    n_garbage_suffix = n_garbage - n_garbage_prefix

    task_description = "There is an important info hidden inside a lot of irrelevant text. Find it and memorize them. I will quiz you about the important information there."
    garbage = "The grass is green. The sky is blue. The sun is yellow. Here we go. There and back again."
    garbage_inf = " ".join([garbage] * 20000)
    assert len(garbage_inf) >= n_garbage
    garbage_prefix = garbage_inf[:n_garbage_prefix]
    garbage_suffix = garbage_inf[:n_garbage_suffix]
    pass_key = random.randint(1, 50000)
    information_line = (
        f"The pass key is {pass_key}. Remember it. {pass_key} is the pass key."
    )
    final_question = "What is the pass key? The pass key is"
    lines = [
        task_description,
        garbage_prefix,
        information_line,
        garbage_suffix,
        final_question,
    ]
    random.set_state(rnd_state)
    lines = "\n".join(lines)
    if FLAGS.replace_last_words_with is not None:
        lines = lines.replace("What is the pass key? The pass key is", FLAGS.replace_last_words_with)

    #print(f"pass_key: {pass_key}")
    return lines, str(pass_key)


class LandmarkTask(CustomTask):
    def __init__(self, seed, max_samples, n_garbage) -> None:
        super().__init__(seed, max_samples)
        self.n_garbage = n_garbage

    def __iter__(self):
        for i in range(self.max_samples):
            input_txt, ans_txt = generate_prompt_landmark(
                self.n_garbage, seed=self.seed + i
            )
            yield input_txt, ans_txt


def main(_):
    print(generate_prompt_landmark(400000, 1)[0])

if __name__ == "__main__":
    app.run(main)
