from .custom_task import CustomTask
import json


def memt_data_proc(data_dict):
    input_txt = data_dict["prompt"]
    db = "\n".join(input_txt.split("\n")[:-1])
    answer_split = data_dict["correct_line"].split(" ")
    query, answer = " ".join(answer_split[:-1]), answer_split[-1]

    prompt = db + query

    prompt = prompt.replace(":", "")

    if answer[-1] == "\n":
        answer = answer[:-1]

    return prompt, answer


class LongChatTask(CustomTask):
    def __init__(self, seed, max_samples, num_lines) -> None:
        super().__init__(seed, max_samples)
        self.num_lines = num_lines

        self.data_processor = memt_data_proc

    def __iter__(self):
        data = []

        file_path = None
        if file_path is None:
            raise ValueError("No path to the dataset")
        print(f"LongChatTask opening {file_path}")
        with open(file_path) as f:
            for line in f:
                raw_data = json.loads(line)
                proc_data = self.data_processor(raw_data)
                data.append(proc_data)

        for i in range(min(self.max_samples, len(data))):
            input_txt, ans_txt = data[i]
            yield input_txt, ans_txt
