from transformers import AutoTokenizer, AutoModelForCausalLM, LogitsProcessorList
from .stopping_crit import StopAfterWordIsGenerated
import transformers
import functools
from absl import flags, app, logging
from .custom_task import CustomTask
from .tasks import get_tasks
import torch
import numpy as np
from ...utils.logging_utils import create_logger, metrics_assign_group
from .eval_utils import (
    InputBatcher,
    forward_eval,
    gen_eval,
    process_results,
    gen_match_eval,
    front_truncate_to_context,
    perplexity_eval,
)
from .answer_processing.graders import get_grader
import gc
import mlxu
from ml_collections import ConfigDict
from tqdm import tqdm
import json


def get_default_tasks_to_run():
    cfg = ConfigDict()
    cfg.task_spec = [
        ("landmark", "gen", [{"seed": 42, "n_garbage": 30, "max_samples": 10}]),
        ("landmark", "forward", [{"seed": 42, "n_garbage": 14000, "max_samples": 10}]),
    ]
    cfg.dtype = "bfloat16"
    cfg.device = "cuda"

    cfg.checkpoint_path = None
    cfg.tokenizer_path = None

    cfg.gen_beams = 1
    cfg.batch_size = 4
    cfg.add_bos_token = True

    cfg.max_new_tokens = None
    cfg.regex = None

    cfg.max_context = None
    cfg.force_transformers_model_code = None
    cfg.model_kwargs = {}
    cfg.forward_pad_right_to = None
    cfg.cross_run_stats = False

    cfg.matcher = {"name": "regex", "kwargs": {}}  # name and kwargs

    cfg.gen_stop_after_list = None
    return cfg


def get_log_group_str(log_name, task_name, mode):
    return log_name + "/" + task_name + "/" + mode


def display_results(logger, id, results, log_name: str, task_name: str, mode: str, run):
    group_str = get_log_group_str(log_name=log_name, task_name=task_name, mode=mode)
    processed_results = process_results(results)
    processed_results = metrics_assign_group(processed_results, group_str)
    logging.info(f"For {group_str} run(s) {run} results are {processed_results}")
    logger.write_scalars(id, processed_results)
    text_logs = {"run_spec": str(run)}
    text_logs = metrics_assign_group(text_logs, group_str)
    logger.write_texts(id, text_logs)

    logger.flush()


def dump_text_results(id, results, log_name: str, task_name: str, mode: str, run):
    with open("dump_text_logs.jsonl", "a") as file:
        text_logs = {
            "job_cfg": FLAGS.custom_eval.to_dict(),
            "text_logs": {
                "id": id,
                "log_name": log_name,
                "task_name": task_name,
                "mode": mode,
                "run": run,
                "results": results,
                "processed_results": process_results(results),
            },
        }
        file.write(json.dumps(text_logs) + "\n")


FLAGS, FLAGS_DEF = mlxu.define_flags_with_default(
    custom_eval=get_default_tasks_to_run()
)


def clear_memory():
    gc.collect()
    torch.cuda.empty_cache()


def get_mem_stats(name: str):
    t = torch.cuda.get_device_properties(0).total_memory
    r = torch.cuda.memory_reserved(0)
    a = torch.cuda.memory_allocated(0)
    print(f"{name}: total: {t/1e9} reserved: {r/1e9} allocated: {a/1e9}")


@torch.no_grad()
def main(argv):
    device = torch.device(FLAGS.custom_eval.device)

    task_dict = get_tasks()
    tokenizer_prefix = AutoTokenizer.from_pretrained(
        FLAGS.custom_eval.tokenizer_path,
        use_fast=False,
        add_bos_token=FLAGS.custom_eval.add_bos_token,
        add_eos_token=False,
        trust_remote_code=True,
    )
    tokenizer_suffix = AutoTokenizer.from_pretrained(
        FLAGS.custom_eval.tokenizer_path,
        use_fast=False,
        add_bos_token=False,
        add_eos_token=False,
        trust_remote_code=True,
    )

    if FLAGS.custom_eval.gen_stop_after_list is not None:
        assert isinstance(FLAGS.custom_eval.gen_stop_after_list, list)
        pure_tokenizer = AutoTokenizer.from_pretrained(
            FLAGS.custom_eval.tokenizer_path,
            use_fast=False,
            add_bos_token=False,
            add_eos_token=False,
            trust_remote_code=True,
        )
        gen_logits_processor = LogitsProcessorList(
            [
                StopAfterWordIsGenerated(
                    stop_words=FLAGS.custom_eval.gen_stop_after_list,
                    tokenizer=pure_tokenizer,
                )
            ]
        )
    else:
        gen_logits_processor = None

    if FLAGS.custom_eval.force_transformers_model_code is not None:
        model = getattr(
            transformers, FLAGS.custom_eval.force_transformers_model_code
        ).from_pretrained(
            FLAGS.custom_eval.checkpoint_path,
            torch_dtype=getattr(torch, FLAGS.custom_eval.dtype),
            device_map=device,
            **FLAGS.custom_eval.model_kwargs,
        )
    else:
        model = AutoModelForCausalLM.from_pretrained(
            FLAGS.custom_eval.checkpoint_path,
            torch_dtype=getattr(torch, FLAGS.custom_eval.dtype),
            trust_remote_code=True,
            **FLAGS.custom_eval.model_kwargs,
            device_map=device,
        )

    model.eval()

    logger = create_logger(log_dir=FLAGS.workdir, enable=True)

    counter = 0

    get_mem_stats("initial model mem: ")

    all_task_steps = 0
    for task in FLAGS.custom_eval.task_spec:
        _, _, runs = task
        for r in runs:
            all_task_steps += r["max_samples"]

    with tqdm(total=all_task_steps) as pbar:
        for task in FLAGS.custom_eval.task_spec:
            task_name, mode, runs = task
            task_gen = task_dict[task_name]
            cross_run_results = []
            for ir, r in enumerate(runs):
                clear_memory()
                dataset = task_gen(**r)
                pbar.set_description(f"Task: {task_name} run: {r}")
                batched_dataset = InputBatcher(
                    dataset=dataset,
                    batch_size=FLAGS.custom_eval.batch_size,
                    prefix_tokenizer=tokenizer_prefix,
                    suffix_tokenizer=tokenizer_suffix,
                    pad_answer_right=(mode != "perplexity"),
                )
                batched_dataset = iter(batched_dataset)
                all_results = []

                first_run = True
                for ((input_tokens, input_mask), input_text), (
                    (
                        answer_tokens,
                        answer_mask,
                    ),
                    answer_text,
                ) in batched_dataset:
                    assert input_tokens.shape == input_mask.shape
                    assert answer_tokens.shape == answer_mask.shape
                    assert len(input_tokens.shape) == 2
                    assert len(answer_tokens.shape) == 2

                    if first_run:
                        example_input_log = {
                            "input_text": "$"
                            + str(tokenizer_suffix.decode(input_tokens[0]))
                            + "#",
                            "input_tokens_shape": str(input_tokens.shape),
                        }

                        example_input_log = metrics_assign_group(
                            example_input_log,
                            get_log_group_str(
                                log_name="per_run", task_name=task_name, mode=mode
                            ),
                        )

                        logger.write_texts(1, example_input_log)
                        logging.info(
                            f'Example input {"$" + str(tokenizer_suffix.decode(input_tokens[0])) + "#"}'
                        )
                        logger.flush()
                        print(
                            f"Example input {json.dumps(example_input_log, indent=2)}"
                        )
                        first_run = False
                    else:
                        example_input_log = None

                    if mode == "forward":
                        full_answer_mask = np.concatenate(
                            [
                                np.zeros_like(input_tokens),
                                answer_mask,
                            ],
                            axis=-1,
                        )
                        results = forward_eval(
                            model=model,
                            input_tokens=front_truncate_to_context(
                                np.concatenate([input_tokens, answer_tokens], axis=-1),
                                FLAGS.custom_eval.max_context,
                                tokenizer=tokenizer_suffix,
                                pad_right_to=(
                                    FLAGS.custom_eval.forward_pad_right_to,
                                    0,
                                ),
                            ),
                            answer_mask=front_truncate_to_context(
                                full_answer_mask,
                                FLAGS.custom_eval.max_context,
                                pad_right_to=(
                                    FLAGS.custom_eval.forward_pad_right_to,
                                    0,
                                ),
                            ),
                            input_mask=front_truncate_to_context(
                                np.concatenate([input_mask, answer_mask], axis=-1),
                                FLAGS.custom_eval.max_context,
                                pad_right_to=(
                                    FLAGS.custom_eval.forward_pad_right_to,
                                    0,
                                ),
                            ),
                            tokenizer=tokenizer_suffix,
                        )
                        results = [metrics_assign_group(r, "forward") for r in results]
                        all_results.extend(results)
                    elif mode == "perplexity":
                        full_answer_mask = np.concatenate(
                            [
                                np.zeros_like(input_tokens),
                                answer_mask,
                            ],
                            axis=-1,
                        )
                        results = perplexity_eval(
                            model=model,
                            input_tokens=front_truncate_to_context(
                                np.concatenate([input_tokens, answer_tokens], axis=-1),
                                FLAGS.custom_eval.max_context,
                                tokenizer=tokenizer_suffix,
                                pad_right_to=(
                                    FLAGS.custom_eval.forward_pad_right_to,
                                    0,
                                ),
                            ),
                            answer_mask=front_truncate_to_context(
                                full_answer_mask,
                                FLAGS.custom_eval.max_context,
                                pad_right_to=(
                                    FLAGS.custom_eval.forward_pad_right_to,
                                    0,
                                ),
                            ),
                            input_mask=front_truncate_to_context(
                                np.concatenate([input_mask, answer_mask], axis=-1),
                                FLAGS.custom_eval.max_context,
                                pad_right_to=(
                                    FLAGS.custom_eval.forward_pad_right_to,
                                    0,
                                ),
                            ),
                        )
                        results = [
                            metrics_assign_group(r, "perplexity") for r in results
                        ]
                        all_results.extend(results)
                    elif mode == "gen":
                        max_input_length = (
                            FLAGS.custom_eval.max_context - answer_tokens.shape[-1]
                            if FLAGS.custom_eval.max_context is not None
                            else None
                        )
                        assert max_input_length > 0
                        results = gen_eval(
                            model=model,
                            prefix_tokens=front_truncate_to_context(
                                input_tokens,
                                max_input_length,
                                tokenizer=tokenizer_suffix,
                            ),
                            prefix_mask=front_truncate_to_context(
                                input_mask, max_input_length
                            ),
                            answer_tokens=answer_tokens,
                            answer_mask=answer_mask,
                            num_beams=FLAGS.custom_eval.gen_beams,
                            gen_logits_processor=gen_logits_processor,
                        )
                        results = [metrics_assign_group(r, "gen") for r in results]
                        all_results.extend(results)
                    elif mode == "gen_match_eval":
                        max_input_length = (
                            FLAGS.custom_eval.max_context
                            - FLAGS.custom_eval.max_new_tokens
                            if FLAGS.custom_eval.max_context is not None
                            else None
                        )
                        assert max_input_length > 0
                        results = gen_match_eval(
                            model=model,
                            prefix_tokens=front_truncate_to_context(
                                input_tokens,
                                max_input_length,
                                tokenizer=tokenizer_suffix,
                            ),
                            prefix_mask=front_truncate_to_context(
                                input_mask, max_input_length
                            ),
                            answer_text=answer_text,
                            max_new_tokens=FLAGS.custom_eval.max_new_tokens,
                            tokenizer=tokenizer_suffix,
                            grader=get_grader(FLAGS.custom_eval.matcher),
                            gen_logits_processor=gen_logits_processor,
                        )
                        all_results.extend(results)
                    else:
                        raise ValueError(f"Not supported mode {mode}")
                    pbar.update(input_tokens.shape[0])

                torch.cuda.empty_cache()
                if FLAGS.custom_eval.cross_run_stats:
                    cross_run_results.append(process_results(all_results))
                display_results(
                    logger=logger,
                    id=counter,
                    results=all_results,
                    log_name="per_run",
                    task_name=task_name,
                    mode=mode,
                    run=r,
                )
                dump_text_results(
                    id=counter,
                    results=all_results,
                    log_name="per_run",
                    task_name=task_name,
                    mode=mode,
                    run=r,
                )
                counter += 1

            if FLAGS.custom_eval.cross_run_stats:
                display_results(
                    logger=logger,
                    id=counter,
                    results=cross_run_results,
                    log_name="summary",
                    task_name=task_name,
                    mode=mode,
                    run=runs,
                )


if __name__ == "__main__":
    app.run(main)
