import re
from .normalization import normalize_answer
from .metrics import normalized_occurence, f1_score, regex_match
from functools import partial
from typing import List, Any


def max_aggregator(metrics: List[dict]):
    result = {}
    for m in metrics:
        for k, v in m.items():
            if k not in result:
                result[k] = v
            else:
                result[k] = max(result[k], v)

    return result


class Grader:
    def __init__(self, grade_fn, aggregate_grades_fn) -> None:
        self.grade_fn = grade_fn
        self.aggregate_grades_fn = aggregate_grades_fn

    def grade(self, prediction, ground_truth):
        return self.grade_fn(prediction=prediction, ground_truth=ground_truth)

    def aggregate(self, grades: List[Any]):
        return self.aggregate_grades_fn(grades)


def get_metric_fn(cfg: dict):
    name = cfg["name"]
    kwargs = cfg["kwargs"]
    if name == "regex":
        return partial(regex_match, **kwargs)
    elif name == "lost_in_the_middle":
        return partial(normalized_occurence, **kwargs)
    elif name == "lost_in_the_middle_kv":
        return partial(normalized_occurence, **kwargs)
    elif name == "hot_pot_qa":
        return partial(f1_score, **kwargs)
    else:
        raise ValueError(f"No metric named {name}")


def get_aggregate_metric_fn(cfg: dict):
    name = cfg["aggregate"]
    if name == "max":
        return max_aggregator
    else:
        raise ValueError(f"No aggregator {name}")


def joint_metric(prediction, ground_truth, metric_fns):
    result = {}
    for mfn in metric_fns:
        result = dict(
            **result, **(mfn(prediction=prediction, ground_truth=ground_truth))
        )

    return result


def get_grader(cfg: dict):
    metric_fns = []
    for m in cfg["metrics"]:
        metric_fns.append(get_metric_fn(m))

    return Grader(
        grade_fn=partial(joint_metric, metric_fns=metric_fns),
        aggregate_grades_fn=get_aggregate_metric_fn(cfg=cfg),
    )
