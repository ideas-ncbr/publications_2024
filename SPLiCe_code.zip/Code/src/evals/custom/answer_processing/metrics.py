from .normalization import normalize_answer

from collections import Counter
import re


def regex_match(prediction: str, ground_truth: str, regex):
    prediction_re_filetered = re.findall(regex, prediction)
    prediction_f = "" if prediction_re_filetered == [] else prediction_re_filetered[-1]

    return {"regex_match": ground_truth == prediction_f}


def normalized_occurence(prediction: str, ground_truth: str):
    prediction = normalize_answer(prediction).lower()
    ground_truth = normalize_answer(ground_truth).lower()
    return {"norm_occur": ground_truth in prediction}


def f1_score(prediction: str, ground_truth: str, drop_after=None):
    """
    Adopted from https://github.com/hotpotqa/hotpot/blob/3635853403a8735609ee997664e1528f4480762a/hotpot_evaluate_v1.py#L26
    """
    if drop_after is not None:
        prediction = prediction.split(drop_after)[0]

    normalized_prediction = normalize_answer(prediction)
    normalized_ground_truth = normalize_answer(ground_truth)

    ZERO_METRIC = {"f1": 0.0, "precision": 0.0, "recall": 0.0}

    if (
        normalized_prediction in ["yes", "no", "noanswer"]
        and normalized_prediction != normalized_ground_truth
    ):
        return ZERO_METRIC
    if (
        normalized_ground_truth in ["yes", "no", "noanswer"]
        and normalized_prediction != normalized_ground_truth
    ):
        return ZERO_METRIC

    prediction_tokens = normalized_prediction.split()
    ground_truth_tokens = normalized_ground_truth.split()
    common = Counter(prediction_tokens) & Counter(ground_truth_tokens)
    num_same = sum(common.values())
    if num_same == 0:
        return ZERO_METRIC
    precision = 1.0 * num_same / len(prediction_tokens)
    recall = 1.0 * num_same / len(ground_truth_tokens)
    f1 = (2 * precision * recall) / (precision + recall)
    return {"f1": f1, "precision": precision, "recall": recall}
