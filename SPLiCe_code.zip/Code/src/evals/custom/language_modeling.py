from datasets import load_dataset
from .custom_task import CustomTask
import random
from datasets import load_dataset


class WikiSimple(CustomTask):
    def __init__(self, seed, max_samples) -> None:
        super().__init__(seed, max_samples)
        self.dataset = load_dataset("wikipedia", "20220301.simple")["train"]

    def __iter__(self):
        i = 0
        for data in self.dataset:
            text = data["text"]
            if len(text) < 128:
                continue
            yield "", text
            i += 1
            if i >= self.max_samples:
                return None
