from .custom_task import CustomTask
from datasets import load_dataset
import numpy as np


class NaturalQuestions(CustomTask):
    def __init__(self, seed, max_samples, num_shots) -> None:
        super().__init__(seed, max_samples)

        self.dataset = lambda split: load_dataset(
            "natural_questions", split=split, streaming=True
        )
        self.num_shots = num_shots

    def get_examples(self):
        train = self.dataset("train")

        example_list = []
        for example in train:
            print(example["document"]["tokens"])
            assert False


nq = NaturalQuestions(42, 10, 2)

nq.get_examples()
