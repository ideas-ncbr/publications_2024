import mlxu
from ml_collections import ConfigDict
from typing import Dict, Any, List
import json


def pcheck_not_none(x):
    return x is not None


def pcheck_list(x):
    return isinstance(x, list)


class Parameter:
    def __init__(self, name: str, value: Any, comment="", checker=lambda x: True):
        self.name = name
        self.value = value
        self.comment = comment
        self.checker = checker

    def assert_check_self(self):
        self.assert_check_value(self, value=self.value)

    def assert_check_value(self, value):
        if not self.checker(value):
            raise ValueError(
                f"For parameter {self.name} value {value} is invalid - check failed"
            )


def prepare_config_dict(parameters: List[Parameter], check_parameters: bool):
    param_dict = {}
    for p in parameters:
        if p.name in param_dict:
            raise ValueError(f"Parameter {p.name} repeats")
        if check_parameters:
            p.assert_check()
        param_dict[p.name] = p.value
    return ConfigDict(initial_dictionary=param_dict)


def check_config(cfg, parameters_to_check: List[Parameter]):
    for p in parameters_to_check:
        v = getattr(cfg, p.name)
        p.assert_check_value(v)


def gather_parameters_in_dict(
    cfg, parameters_to_gather: List[Parameter], param_add_prefix: str = ""
):
    result = {}
    for p in parameters_to_gather:
        value = getattr(cfg, p.name)
        if hasattr(value, "to_dict"):
            value = value.to_dict()
        result[param_add_prefix + p.name] = value

    return result


def dump_parameters(
    cfg,
    parameters_to_dump: List[Parameter],
    dump_path: str,
    param_add_prefix: str = "",
    additional_data={},
):

    params = gather_parameters_in_dict(
        cfg, parameters_to_dump, param_add_prefix=param_add_prefix
    )
    params["$additional_info"] = additional_data
    with mlxu.open_file(dump_path, "w") as f:
        f.write(json.dumps(params, indent=2))
