from absl import flags
import logging
import sys

flags.DEFINE_string("debug_modes", "", "comma separated list of modes")

DEBUG_LOGGER = logging.Logger("DEBUG:", level=logging.DEBUG)
DEBUG_LOGGER_HANDLER = logging.StreamHandler(sys.stderr)
DEBUG_LOGGER_HANDLER.setFormatter(
    logging.Formatter("[%(asctime)s]  [%(levelname)s] : %(message)s")
)
DEBUG_LOGGER.addHandler(DEBUG_LOGGER_HANDLER)
FLAGS = flags.FLAGS


def debug_get_logger(logger):
    if logger is None:
        return DEBUG_LOGGER
    else:
        return logger


def should_debug_inputs():
    return "print_input" in FLAGS.debug_modes


def debug_inputs(data, logger=None):
    if should_debug_inputs():
        debug_get_logger(logger).debug(str(data))


def should_debug_outputs():
    return "print_output" in FLAGS.debug_modes


def debug_outputs(data, logger=None):
    if should_debug_outputs():
        debug_get_logger(logger).debug(str(data))


def should_debug_stats():
    return "stats" in FLAGS.debug_modes


def debug_stats(data, logger=None):
    if should_debug_stats():
        debug_get_logger(logger).debug(str(data))
