from ...utils.prepare_parameters import (
    Parameter,
    prepare_config_dict,
    pcheck_not_none,
    check_config,
    dump_parameters,
    gather_parameters_in_dict,
)
from ..utils.record_loader import read_one_record
from ..basic_data_ops.merge_datasets import load_proportionally
from .splice_main import get_records_from_dataset
import mlxu
from ..utils.file_utils import BuffferedFile
import logging
import sys
from ...utils.multi_logging import MultiLogger
from ..utils.file_utils import DatasetWriter
import json
from .retrievers.base_retriever import IndexedData
from .retrievers.get_retriver import get_retriever
from .stats import DatasetStats, ExampleStats
import tqdm
from queue import Queue
from typing import List, Optional
import random
from datasets import load_dataset
from absl import app
import os
from .retrievers.get_retriver import (
    get_default_parameters as get_default_parameters_retrievers,
)

LOGGER = logging.Logger("SPLiCe Mixture", level=logging.INFO)
LOGGER_HANDLER = logging.StreamHandler(sys.stderr)
LOGGER_HANDLER.setFormatter(
    logging.Formatter("[%(asctime)s] SPM [%(levelname)s] : %(message)s")
)
LOGGER.addHandler(LOGGER_HANDLER)
LOGGER = MultiLogger(basic_loggers=[print], advanced_loggers=[LOGGER])


def get_default_parameters():
    return [
        Parameter("splice_source", None, ";str", pcheck_not_none),
        Parameter(
            "splice_content_field",
            None,
            "field with text for splice source; str",
            pcheck_not_none,
        ),
        Parameter(
            "splice_take_char_prefix",
            None,
            "how many chars to load from the dataset; int",
            pcheck_not_none,
        ),
        Parameter("splice_tokenizer_path", None, "; str"),
        #
        Parameter(
            "splice_aggregate_mode",
            None,
            "bm25|repo|random|plain|...; str",
            pcheck_not_none,
        ),
        Parameter("splice_topk", None, "value of topk; int", pcheck_not_none),
        Parameter("splice_topk_sample", None, "what subset of topk to sample; int"),
        Parameter(
            "splice_random_shuffle_tree",
            None,
            "shuffle splice tree; bool",
            pcheck_not_none,
        ),
        Parameter(
            "splice_reverse_tree",
            None,
            "whether to reverse the splice tree; bool",
            pcheck_not_none,
        ),
        #
        Parameter(
            "splice_min_len_in_chars",
            None,
            "filter out shorter docs; int",
            pcheck_not_none,
        ),
        Parameter(
            "splice_max_doc_chars",
            None,
            "max length of the created doc in chars; int",
            pcheck_not_none,
        ),
        Parameter(
            "splice_randomize_max_doc_chars_lower_bound",
            None,
            "max length of the created doc in chars; int",
        ),
        Parameter(
            "splice_prefilter_max_doc_chars",
            None,
            "filter out longer docs from splice_source; int",
            pcheck_not_none,
        ),
        Parameter(
            "splice_precompute", None, "precompute neighbors; bool", pcheck_not_none
        ),
        Parameter(
            "splice_max_total_chars",
            None,
            "max chars in generated dataset; int",
            pcheck_not_none,
        ),
        #
        Parameter(
            "splice_stop_fraction",
            None,
            "stop after generating this fraction of chars; float",
            pcheck_not_none,
        ),
        Parameter("splice_cutoff_base", 100, "nn_search base; int", pcheck_not_none),
        #
        Parameter(
            "other_sources", None, "paths to jsonl datasets; List[str]", pcheck_not_none
        ),
        Parameter(
            "other_sources_content_fields",
            None,
            "per other_source field with text; List[str]",
            pcheck_not_none,
        ),
        Parameter(
            "output_origin_field",
            "source_dataset",
            "field where data origin will be saved; str",
            pcheck_not_none,
        ),
        #
        Parameter(
            "all_data_proportions", None, "proportions including splice; List[float]"
        ),
        Parameter(
            "all_data_origins",
            None,
            "data origins including splice; Optional[List[float]]",
        ),
        #
        Parameter("mixture_max_chars", None, "max chars in mixture; int"),
        Parameter(
            "mixture_max_tokens",
            None,
            "(hf_tokenizer_path, max_tokens); Tuple[str, int]",
        ),
        Parameter("seed", 42, "; int"),
        #
        Parameter("dest_path", None, ";str", pcheck_not_none),
        Parameter("noise", 0.0, "amount of random noise in preparation process"),
    ]


FLAGS, _ = mlxu.define_flags_with_default(
    splice_mixture=prepare_config_dict(get_default_parameters(), check_parameters=False)
)


def get_splice_data_path(
    splice_source: str,
    splice_content_field: str,
    dest_path: str,
    splice_topk: int,
    splice_max_doc_chars: int,
    splice_aggregate_mode: str,
    splice_min_len_in_chars: int,
    splice_max_total_chars: int,
    splice_precompute: bool,
    splice_stop_fraction: float,
    splice_prefilter_max_doc_chars: int,
    splice_random_shuffle_tree: bool,
    splice_topk_sample: int,
    splice_reverse_tree: bool,
    splice_take_char_prefix: int,
    splice_tokenizer_path: Optional[str],
    splice_cutoff_base: int,
    splice_randomize_max_doc_chars_lower_bound: Optional[int],
    splice_noise: float,
):
    LOGGER.info(
        f"SSTP sources {splice_source} fields {splice_content_field} topks {splice_topk} max_chars_per_doc {splice_max_doc_chars}"
        f"aggregate_modes {splice_aggregate_mode} max_total_chars {splice_max_total_chars} precompute {splice_precompute}"
        f"stop_fraction {splice_stop_fraction} prefilter_max_docs_chars {splice_prefilter_max_doc_chars} sstp_random_shuffle_tree {splice_random_shuffle_tree}"
        f"sstp_topk_sample {splice_topk_sample} sstp_reverse_tree {splice_reverse_tree} sstp_take_char_prefix {splice_take_char_prefix}"
        f"sstp_tokenizer_path {splice_tokenizer_path}"
    )

    records, stats = get_records_from_dataset(
        ds_mode="file",
        ds_path=splice_source,
        ds_subset=None,
        ds_split=None,
        topk=splice_topk,
        max_doc_chars=splice_max_doc_chars,
        aggregate_mode=splice_aggregate_mode,
        content_field=splice_content_field,
        min_len_in_chars=splice_min_len_in_chars,
        max_total_chars=splice_max_total_chars,
        precompute=splice_precompute,
        stop_fraction=splice_stop_fraction,
        prefilter_max_doc_chars=splice_prefilter_max_doc_chars,
        random_shuffle_tree=splice_random_shuffle_tree,
        topk_sample=splice_topk_sample,
        reverse_tree=splice_reverse_tree,
        take_char_prefix=splice_take_char_prefix,
        tokenizer_path=splice_tokenizer_path,
        cutoff_base=splice_cutoff_base,
        randomize_max_doc_chars_lower_bound=splice_randomize_max_doc_chars_lower_bound,
        procedure_noise=splice_noise,
    )

    tmp_dest = dest_path + ".tmp.jsonl"
    with DatasetWriter(
        tmp_dest,
        expected_chars=stats["characters_added"],
        text_field="text",
        add_time_stamp=False,
    ) as dw:
        for r in records:
            dw.add(r)

    return tmp_dest, stats


def main(_):
    check_config(FLAGS.splice_mixture, get_default_parameters())
    random.seed(FLAGS.splice_mixture.seed)
    assert (
        FLAGS.splice_mixture.all_data_proportions is None
        or abs(sum(FLAGS.splice_mixture.all_data_proportions) - 1.0) <= 1e-4
    )
    assert len(FLAGS.splice_mixture.other_sources) == len(
        FLAGS.splice_mixture.other_sources_content_fields
    )
    assert len(FLAGS.splice_mixture.other_sources) + 1 == len(
        FLAGS.splice_mixture.all_data_origins
    )
    splice_file, splice_stats = get_splice_data_path(
        splice_source=FLAGS.splice_mixture.splice_source,
        splice_content_field=FLAGS.splice_mixture.splice_content_field,
        dest_path=FLAGS.splice_mixture.dest_path,
        splice_topk=FLAGS.splice_mixture.splice_topk,
        splice_max_doc_chars=FLAGS.splice_mixture.splice_max_doc_chars,
        splice_aggregate_mode=FLAGS.splice_mixture.splice_aggregate_mode,
        splice_min_len_in_chars=FLAGS.splice_mixture.splice_min_len_in_chars,
        splice_max_total_chars=FLAGS.splice_mixture.splice_max_total_chars,
        splice_precompute=FLAGS.splice_mixture.splice_precompute,
        splice_random_shuffle_tree=FLAGS.splice_mixture.splice_random_shuffle_tree,
        splice_stop_fraction=FLAGS.splice_mixture.splice_stop_fraction,
        splice_prefilter_max_doc_chars=FLAGS.splice_mixture.splice_prefilter_max_doc_chars,
        splice_topk_sample=FLAGS.splice_mixture.splice_topk_sample,
        splice_reverse_tree=FLAGS.splice_mixture.splice_reverse_tree,
        splice_take_char_prefix=FLAGS.splice_mixture.splice_take_char_prefix,
        splice_tokenizer_path=FLAGS.splice_mixture.splice_tokenizer_path,
        splice_cutoff_base=FLAGS.splice_mixture.splice_cutoff_base,
        splice_randomize_max_doc_chars_lower_bound=FLAGS.splice_mixture.splice_randomize_max_doc_chars_lower_bound,
        splice_noise=FLAGS.splice_mixture.noise,
    )

    all_files = [splice_file] + FLAGS.splice_mixture.other_sources
    source_fields = ["text"] + FLAGS.splice_mixture.other_sources_content_fields

    LOGGER.info(f"Source Files are {all_files}")

    files = [mlxu.open_file(fp, "r") for fp in all_files]

    record_list = load_proportionally(
        files=files,
        source_fields=source_fields,
        destination_field="text",
        proportions=FLAGS.splice_mixture.all_data_proportions,
        max_chars=FLAGS.splice_mixture.mixture_max_chars,
        max_tokens=FLAGS.splice_mixture.mixture_max_tokens,
        origin_field_name="source_dataset",
        origin_to_add=FLAGS.splice_mixture.all_data_origins,
    )

    LOGGER.info(f"Shuffling")
    random.shuffle(record_list)
    if FLAGS.splice_mixture.all_data_proportions is None:
        print_data_props = ["na"] * len(FLAGS.splice_mixture.all_data_origins)
    else:
        print_data_props = FLAGS.splice_mixture.all_data_proportions

    origin_tag = ""
    for o, p in zip(FLAGS.splice_mixture.all_data_origins, print_data_props):
        origin_tag += str(o) + "-" + str(p)

    for sstpm, sstprst, sstptopk, sstptopks, sstprt, sstp_tok_path in zip(
        [FLAGS.splice_mixture.splice_aggregate_mode],
        [FLAGS.splice_mixture.splice_random_shuffle_tree],
        [FLAGS.splice_mixture.splice_topk],
        [FLAGS.splice_mixture.splice_topk_sample],
        [FLAGS.splice_mixture.splice_reverse_tree],
        [FLAGS.splice_mixture.splice_tokenizer_path],
    ):
        origin_tag += f".{sstpm}_tk{sstptopk}s{sstptopks}_rst{sstprst}_revt{sstprt}_tok{sstp_tok_path}."

    destination_path = FLAGS.splice_mixture.dest_path + f"mix_{origin_tag}.jsonl"

    LOGGER.info(f"Saving to {destination_path}")
    print(f"Saving to {destination_path}")

    dest_f = BuffferedFile(destination_path)

    for r in record_list:
        dest_f.write(json.dumps(r) + "\n")

    dest_f.close()

    for f in files:
        f.close()

    retriver_params = gather_parameters_in_dict(
        FLAGS.get_retriever, get_default_parameters_retrievers(), "get_retriever."
    )
    dump_parameters(
        FLAGS.splice_mixture,
        get_default_parameters(),
        destination_path + ".meta.json",
        "splice_mixture.",
        {"splice_stats": splice_stats, **retriver_params},
    )

    LOGGER.info(f"Done")
