from .retrievers.base_retriever import IndexedData
import numpy as np


class ExampleStats:
    def __init__(self, indexed_data: IndexedData) -> None:
        self.indexed_data = indexed_data
        self.stats = {"repos": set(), "file_lengths": []}

    def update(self, node):
        id = node["id"]
        node = self.indexed_data[id]
        self.stats["repos"].add(node["repo_name"])
        self.stats["file_lengths"].append(len(node["text"]))

    def get_stats(self):
        return self.stats


class DatasetStats:
    def __init__(self) -> None:
        self.per_example_stats: ExampleStats = []

    def update(self, example_stats: ExampleStats):
        self.per_example_stats.append(example_stats)

    def create_summary(self):

        keys = ["repos", "file_lengths"] if len(self.per_example_stats) > 0 else []
        per_key_data = {
            "num_repos_in_example": [],
            "num_files_in_example": [],
            "example_length": [],
        }
        for k in keys:
            for e in self.per_example_stats:
                e = e.get_stats()
                if k == "repos":
                    per_key_data["num_repos_in_example"].append(len(e[k]))
                elif k == "file_lengths":
                    per_key_data["num_files_in_example"].append(len(e[k]))
                    per_key_data["example_length"].append(np.sum(e[k]))

        result = {}
        for k, v in per_key_data.items():
            result[f"{k}_min"] = np.min(v).item() if len(v) != 0 else None
            result[f"{k}_max"] = np.max(v).item() if len(v) != 0 else None
            result[f"{k}_median"] = np.median(v).item() if len(v) != 0 else None
            result[f"{k}_mean"] = np.mean(v).item() if len(v) != 0 else None
            result[f"{k}_std"] = np.std(v).item() if len(v) != 0 else None

        result["num_examples"] = len(self.per_example_stats)

        return result
