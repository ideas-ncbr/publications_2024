from typing import List, Optional
import sys
import logging
from ....utils.multi_logging import MultiLogger
import random
import functools
import string
from transformers import LlamaTokenizer
from ...retriv.retriv import SearchEngine
from joblib import Parallel, delayed

LOGGER = logging.Logger("Parquet dataset", level=logging.INFO)
LOGGER_HANDLER = logging.StreamHandler(sys.stderr)
LOGGER_HANDLER.setFormatter(
    logging.Formatter("[%(asctime)s] TSPPGatherer [%(levelname)s] : %(message)s")
)
LOGGER.addHandler(LOGGER_HANDLER)

LOGGER = MultiLogger(basic_loggers=[print], advanced_loggers=[LOGGER])


class IndexedData:
    def __init__(self, data) -> None:
        self.data = [
            {
                "id": i,
                "text": doc["text"],
                "repo_name": doc.get("repo_name", None),
                "repo_path": doc.get("repo_path", None),
            }
            for i, doc in enumerate(data)
        ]

        self.marked = set()
        self.nearest_neighbors = None

    def __len__(self):
        return len(self.data)

    def __getitem__(self, i: int):
        return self.data[i]

    def get_marked_fraction(self):
        return len(self.marked) / max(len(self.data), 1)

    def mark_data(self, data: dict):
        assert data["id"] not in self.marked
        self.marked.add(data["id"])

    def is_data_marked(self, data: dict):
        return data["id"] in self.marked

    def unmark_data(self, data: dict):
        self.marked.remove(data["id"])

    def iter_unmarked(self):
        for d in self.data:
            if d["id"] in self.marked:
                continue
            yield d

    def precompute_nn(self, retriever, cutoff):
        self.nearest_neighbors = retriever.bsearch(node_list=self.data, cutoff=cutoff)

    def get_precomputed_nn(self, node):
        assert self.nearest_neighbors is not None
        node_id = node["id"]
        assert self.data[node_id]["id"] == node_id
        result = self.nearest_neighbors[node_id]
        return result


class RetrieverBase:
    def __init__(self, indexed_data: IndexedData):
        self.indexed_data = indexed_data

    def search(self, node: dict, cutoff: int):
        raise NotImplementedError

    def bsearch(self, node_list: List[dict], cutoff: int) -> List[List[dict]]:
        result = []
        for node in node_list:
            result.append(self.search(node=node, cutoff=cutoff))

        return result
