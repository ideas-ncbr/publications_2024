from .base_retriever import RetrieverBase, IndexedData, LOGGER
from pyserini.encode import TctColBertDocumentEncoder, TctColBertQueryEncoder
import numpy as np
import faiss
from tqdm import tqdm
import torch
from typing import List, Optional
from transformers import FlaxBertModel, AutoTokenizer
import jax.numpy as jnp
import jax


def iterate_in_batches(data, batch_size):
    res = []
    for d in tqdm(data):
        res.append(d)
        if len(res) >= batch_size:
            yield res
            res = []

    if len(res) > 0:
        yield res


class GenericEncoder:
    def __init__(self):
        pass

    def encode(self, texts: List[str]):
        pass


def get_embedding_mean(embeddings, input_mask):
    assert len(input_mask.shape) == 2  # [BATCH, SEQ]
    assert len(embeddings.shape) == 3  # [BATCH, SEQ, HD]
    assert input_mask.shape == embeddings.shape[:2]
    res = jnp.sum(input_mask[..., None] * embeddings, axis=1) / jnp.maximum(
        jnp.sum(input_mask, axis=1)[..., None], 1.0
    )
    return res


class FlaxEncoder(GenericEncoder):
    def __init__(
        self, model, tokenizer, max_length: int, input_prefix: str = "", steps=1
    ):
        super().__init__()

        self.model = model
        self.tokenizer = tokenizer
        self.max_length = max_length
        self.input_prefix = input_prefix
        self.steps = steps

        def wrapped_model(input_dict: dict):
            return self.model(**input_dict)

        self.mapped_model = jax.pmap(wrapped_model, (0,))
        self.dev_count = jax.device_count()

    def encode(self, texts: List[str]):
        texts = [self.input_prefix + t for t in texts]
        inputs = self.tokenizer(
            texts,
            max_length=self.max_length * self.steps,
            padding="max_length",
            truncation=True,
            # add_special_tokens=False,
            return_tensors="np",
        )

        batch_size = len(texts)

        step_embeddings = []
        for i in range(self.steps):
            step_inputs = jax.tree_util.tree_map(
                lambda x: x[:, i * self.max_length : (i + 1) * self.max_length],
                dict(**inputs),
            )

            if batch_size % self.dev_count == 0:
                pmap_inputs = jax.tree_util.tree_map(
                    lambda x: x.reshape(
                        (self.dev_count, batch_size // self.dev_count) + x.shape[1:]
                    ),
                    dict(**step_inputs),
                )
                step_outputs = self.mapped_model(pmap_inputs)
                step_outputs = jax.tree_util.tree_map(
                    lambda x: x.reshape((batch_size,) + x.shape[2:]), step_outputs
                )
            else:
                step_outputs = self.model(**step_inputs)

            step_embeddings.append(
                np.array(
                    get_embedding_mean(
                        step_outputs["last_hidden_state"], step_inputs["attention_mask"]
                    )
                )
            )

        step_embeddings = np.concatenate(step_embeddings, axis=-1)
        assert (
            step_embeddings.shape[0] == batch_size and len(step_embeddings.shape) == 2
        )
        return step_embeddings


class FlaxBertBasedEncoder(FlaxEncoder):
    def __init__(
        self,
        model: str,
        tokenizer: str,
        max_length: int,
        input_prefix: str = "",
        steps=1,
    ):
        model = FlaxBertModel.from_pretrained(model, from_pt=True)
        tokenizer = AutoTokenizer.from_pretrained(tokenizer)
        super().__init__(model, tokenizer, max_length, input_prefix, steps)


class ModelRetrieverFaiss(RetrieverBase):
    def __init__(
        self,
        indexed_data: IndexedData,
        encoder: GenericEncoder,
        batch_size=128,
        index_spec={"kwargs": {}, "params": {}},
        index_path=None,
        train_batch=65536,
    ):
        super().__init__(indexed_data)

        self.encoder = encoder
        embedding_list = []
        for d in iterate_in_batches(data=self.indexed_data, batch_size=batch_size):
            pure_text = list(map(lambda x: x["text"], d))
            embeddings = self.encoder.encode(pure_text)
            assert embeddings.shape[0] == len(pure_text)
            assert len(embeddings.shape) == 2
            embedding_list.append(embeddings)

        self.embeddings = np.concatenate(embedding_list, 0)
        train_batch = min(train_batch, self.embeddings.shape[0])

        if index_path is not None:
            self.index = faiss.read_index(index_path)
        else:
            assert index_path is None
            self.index = faiss.index_factory(
                self.embeddings.shape[-1],
                index_spec["spec_str"],
                faiss.METRIC_INNER_PRODUCT,
                **index_spec["kwargs"]
            )

            train_batch_ids = np.random.choice(
                np.arange(self.embeddings.shape[0]), train_batch
            )
            self.index.train(self.embeddings[train_batch_ids])

        self.index.add(self.embeddings)

        for pn, pv in index_spec["params"].items():
            faiss.ParameterSpace().set_index_parameter(self.index, pn, pv)

    def bsearch_aux(self, node_list: List[dict], cutoff: int) -> List[List[dict]]:
        queries = [self.embeddings[node["id"]] for node in node_list]
        queries = np.stack(queries, axis=0)
        assert len(queries.shape) == 2
        assert queries.shape[0] == len(node_list)

        _, batch_res_ids = self.index.search(queries, cutoff)
        assert batch_res_ids.shape == (queries.shape[0], cutoff)

        batch_result = []
        for q_res_ids in batch_res_ids:
            q_result = []
            non_empty = list(q_res_ids[q_res_ids != -1])
            for rid in non_empty:
                q_result.append(self.indexed_data[rid])
            batch_result.append(q_result)

        return batch_result

    def bsearch(
        self, node_list: List[dict], cutoff: int, batch_size=2048
    ) -> List[List[dict]]:
        res = []
        for i in tqdm(range(0, len(node_list), 2048), desc="batched search"):
            res.extend(
                self.bsearch_aux(
                    node_list=node_list[i : (i + batch_size)], cutoff=cutoff
                )
            )
        return res

    def search(self, node: dict, cutoff: int):
        query = self.embeddings[[node["id"]]]
        _, res_id = self.index.search(query, cutoff)
        assert res_id.shape[0] == 1
        res_id = res_id[0]
        res_id = list(res_id[res_id != -1])

        result = []
        for rid in res_id:
            result.append(self.indexed_data[rid])
        return result


class ContrieverMSMarco(ModelRetrieverFaiss):
    def __init__(
        self,
        indexed_data: IndexedData,
        encoder: GenericEncoder = None,
        batch_size=128,
        index_spec={"kwargs": {}, "params": {}},
        index_path=None,
        train_batch=65536,
        enc_steps=1,
    ):
        if encoder is None:
            encoder = FlaxBertBasedEncoder(
                model="facebook/contriever-msmarco",
                tokenizer="facebook/contriever-msmarco",
                max_length=512,
                input_prefix="",
                steps=enc_steps,
            )
        super().__init__(
            indexed_data, encoder, batch_size, index_spec, index_path, train_batch
        )


class Contriever(ModelRetrieverFaiss):
    def __init__(
        self,
        indexed_data: IndexedData,
        encoder: GenericEncoder = None,
        batch_size=128,
        index_spec={"kwargs": {}, "params": {}},
        index_path=None,
        train_batch=65536,
        enc_steps=1,
    ):
        if encoder is None:
            encoder = FlaxBertBasedEncoder(
                model="facebook/contriever",
                tokenizer="facebook/contriever",
                max_length=512,
                input_prefix="",
                steps=enc_steps,
            )
        super().__init__(
            indexed_data, encoder, batch_size, index_spec, index_path, train_batch
        )


class BertRetriever(RetrieverBase):
    def __init__(
        self,
        indexed_data: IndexedData,
        batch_size=32,
        index_spec={"kwargs": {}, "params": {}},
        index_path=None,
        train_batch=65536,
    ):
        super().__init__(indexed_data)

        self.bert = TctColBertDocumentEncoder(
            model_name="castorini/tct_colbert-v2-hnp-msmarco", device="cpu"
        )
        embedding_list = []
        for d in iterate_in_batches(data=self.indexed_data, batch_size=batch_size):
            pure_text = list(map(lambda x: x["text"], d))
            print(torch.get_num_threads())
            with torch.no_grad():
                embeddings = self.bert.encode(pure_text, fp16=False)
            assert embeddings.shape[0] == len(pure_text)
            assert len(embeddings.shape) == 2
            embedding_list.append(embeddings)

        self.embeddings = np.concatenate(embedding_list, 0)
        train_batch = min(train_batch, self.embeddings.shape[0])
        if index_path is not None:
            self.index = faiss.read_index(index_path)
        else:
            assert index_path is None
            self.index = faiss.index_factory(
                self.embeddings.shape[-1],
                index_spec["spec_str"],
                faiss.METRIC_INNER_PRODUCT,
                **index_spec["kwargs"]
            )

            train_batch_ids = np.random.choice(
                np.arange(self.embeddings.shape[0]), train_batch
            )
            self.index.train(self.embeddings[train_batch_ids])

        self.index.add(self.embeddings)

        for pn, pv in index_spec["params"].items():
            faiss.ParameterSpace().set_index_parameter(self.index, pn, pv)

    def search(self, node: dict, cutoff: int):
        # query = self.bert.encode([node["text"]])
        query = self.embeddings[[node["id"]]]
        _, res_id = self.index.search(query, cutoff)
        assert res_id.shape[0] == 1
        res_id = res_id[0]
        res_id = list(res_id[res_id != -1])

        result = []
        for rid in res_id:
            result.append(self.indexed_data[rid])
        return result
