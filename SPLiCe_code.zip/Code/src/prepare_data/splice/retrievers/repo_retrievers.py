from .base_retriever import LOGGER, IndexedData, RetrieverBase
from typing import Optional
import random
import string


def get_repo_path_with_id(data: dict):
    print(data)
    return data["repo_path"] + f"#{data['id']}"


class RepoRetrieverBase(RetrieverBase):
    def __init__(self, indexed_data: IndexedData):
        super().__init__(indexed_data)
        self.path_to_data = {"__/$/catalog": True}  # this should be a hash map
        for d in indexed_data:
            RepoRetrieverBase.append_to_catalog(d, self.path_to_data)

        LOGGER.debug(
            f"RepoRetriever: {len(self.path_to_data)} repos, {len(indexed_data)} files; {len(indexed_data)/len(self.path_to_data)}"
        )

    def append_to_catalog(data: dict, catalog_root: dict):
        repo = data["repo_name"]
        path = get_repo_path_with_id(data).split("/")
        full_path = [repo] + path
        assert len(full_path) > 1

        catalog = catalog_root
        for dir in full_path[:-1]:
            if dir not in catalog:
                catalog[dir] = {"__/$/catalog": True}
            catalog = catalog[dir]

        dir = full_path[-1]
        assert dir not in catalog
        catalog[dir] = data

    def retrieve_repo_dfs(
        data: dict, catalog_root: dict, indexed_data: Optional[IndexedData] = None
    ):
        def dfs(node: dict, result: list, current_path: str, path_to_range: dict):
            if "__/$/catalog" not in node:
                assert "id" in node and "text" in node
                beg = len(result)
                if indexed_data is None or (not indexed_data.is_data_marked(node)):
                    result.append(node)

                path_to_range[current_path] = (beg, len(result))
            else:
                path_begin = len(result)
                for k, v in node.items():
                    if k != "__/$/catalog":
                        next_path = current_path + "/" + k if current_path != "" else k
                        dfs(
                            v,
                            result,
                            current_path=next_path,
                            path_to_range=path_to_range,
                        )

                path_end = len(result)
                path_to_range[current_path] = (path_begin, path_end)

        result = []
        path_to_range = {}
        repo = data["repo_name"]
        dfs(
            node=catalog_root[repo],
            result=result,
            current_path="",
            path_to_range=path_to_range,
        )
        return result, path_to_range

    def search(self, node: dict, cutoff: int):
        repo_files, path_to_range = RepoRetrieverBase.retrieve_repo_dfs(
            node, self.path_to_data, self.indexed_data
        )
        random.shuffle(repo_files)
        result = repo_files[:cutoff]
        LOGGER.debug(
            f"RepoRetrieverBase retrieved {len(result)} files from {node['repo_name']}"
        )
        return result


class RepoRetrieverCatalog(RepoRetrieverBase):
    def __init__(self, indexed_data: IndexedData):
        super().__init__(indexed_data)

    def search(self, node: dict, cutoff: int):
        def cat_list_to_path(cat_list: list):
            return "/".join(cat_list)

        repo_files, path_to_range = RepoRetrieverBase.retrieve_repo_dfs(
            node, self.path_to_data, self.indexed_data
        )

        node_path = get_repo_path_with_id(node).split("/")
        beg, end = (
            path_to_range[cat_list_to_path(node_path)][0],
            path_to_range[cat_list_to_path(node_path)][0],
        )
        result = []
        for path_end in range(len(node_path), -1, -1):
            super_path = cat_list_to_path(node_path[:path_end])
            new_beg, new_end = path_to_range[super_path]
            new_files = repo_files[new_beg:beg] + repo_files[end:new_end]
            random.shuffle(new_files)
            beg, end = new_beg, new_end
            result = result + new_files

        assert len(result) == len(repo_files)
        result = result[:cutoff]
        LOGGER.debug(
            f"RepoRetrieverCatalog retrieved {len(result)} files from {node['repo_name']} with {len(repo_files)} unmarked files"
        )
        return result


def tokenizer_wrapper(record: str, tokenizer):
    text = record["text"]

    symbols = [str(i) for i in range(10)] + [s for s in string.ascii_lowercase]

    def to_32_num_base(number):
        base = len(symbols)
        assert number >= 0
        if number == 0:
            return "0"
        else:
            digits = []
            while number > 0:
                digits.append(symbols[number % base])
                number = number // base
            return "".join(digits[::-1])

    assert isinstance(text, str)
    tokens = tokenizer.encode(text)
    assert isinstance(tokens, list)
    encoded_tokens = " ".join(list(map(lambda t: to_32_num_base(int(t)), tokens)))
    new_record = {}
    new_record["id"] = record["id"]
    new_record["text"] = encoded_tokens
    return new_record
