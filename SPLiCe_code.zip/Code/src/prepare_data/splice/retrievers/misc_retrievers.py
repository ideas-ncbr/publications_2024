import random
from .base_retriever import RetrieverBase, IndexedData, LOGGER


class RandomRetriever(RetrieverBase):
    def __init__(self, indexed_data: IndexedData):
        super().__init__(indexed_data)

    def search(self, node: dict, cutoff: int):
        result = []
        sample = random.sample(
            range(len(self.indexed_data)), min(cutoff, len(self.indexed_data))
        )
        for id in sample:
            result.append(self.indexed_data[id])

        return result


class EmptyRetriever(RetrieverBase):
    def __init__(self, indexed_data: IndexedData):
        super().__init__(indexed_data)

    def search(self, node: dict, cutoff: int):
        return []
