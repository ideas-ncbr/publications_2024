from .base_retriever import IndexedData
from typing import Optional
from .bm25_retrievers import BM25Retriever
from .misc_retrievers import EmptyRetriever, RandomRetriever
from .repo_retrievers import RepoRetrieverBase, RepoRetrieverCatalog
from .dense_retrievers import BertRetriever, ContrieverMSMarco, Contriever
from ....utils.prepare_parameters import (
    Parameter,
    prepare_config_dict,
    pcheck_not_none,
    check_config,
    dump_parameters,
)

import mlxu


def get_default_parameters():
    return [
        Parameter("retriever_kwargs", {}, "dict"),
    ]


FLAGS, _ = mlxu.define_flags_with_default(
    get_retriever=prepare_config_dict(get_default_parameters(), check_parameters=False)
)


def get_retriever(mode, indexed_data: IndexedData, tokenizer_path: Optional[str]):
    if mode == "bm25":
        return BM25Retriever(
            indexed_data=indexed_data,
            tokenizer_path=tokenizer_path,
            **FLAGS.get_retriever.retriever_kwargs,
        )
    elif mode == "repo":
        return RepoRetrieverBase(
            indexed_data=indexed_data, **FLAGS.get_retriever.retriever_kwargs
        )
    elif mode == "repocatalog":
        return RepoRetrieverCatalog(
            indexed_data=indexed_data, **FLAGS.get_retriever.retriever_kwargs
        )
    elif mode == "random":
        return RandomRetriever(
            indexed_data=indexed_data, **FLAGS.get_retriever.retriever_kwargs
        )
    elif mode == "plain":
        return EmptyRetriever(
            indexed_data=indexed_data, **FLAGS.get_retriever.retriever_kwargs
        )
    elif mode == "bert":
        return BertRetriever(
            indexed_data=indexed_data, **FLAGS.get_retriever.retriever_kwargs
        )
    elif mode == "contrievermsmarco":
        return ContrieverMSMarco(
            indexed_data=indexed_data, **FLAGS.get_retriever.retriever_kwargs
        )
    elif mode == "contriever":
        return Contriever(
            indexed_data=indexed_data, **FLAGS.get_retriever.retriever_kwargs
        )
    else:
        raise ValueError(f"Mode {mode} not supported")
