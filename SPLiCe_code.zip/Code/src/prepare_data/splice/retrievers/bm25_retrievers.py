from .base_retriever import RetrieverBase, IndexedData, LOGGER
from typing import Optional, List
from joblib import Parallel, delayed
from ...retriv.retriv import SearchEngine
import functools


class BM25Retriever(RetrieverBase):
    def __init__(self, indexed_data: IndexedData, tokenizer_path: Optional[str]):
        super().__init__(indexed_data)

        if tokenizer_path is not None:
            assert False, "Not supported"
            tokenizer = functools.partial(
                tokenizer_wrapper,
                tokenizer=LLaMATokenizer(
                    vocab_file=tokenizer_path,
                    add_bos_token=False,
                    add_eos_token=False,
                ),
            )
            self.tokenizer = tokenizer
            delayed_tokenizer = delayed(self.tokenizer)
            pretokenized_indexed_data = Parallel(n_jobs=32)(
                delayed_tokenizer(d) for d in indexed_data
            )
        else:
            self.tokenizer = None
            pretokenized_indexed_data = [
                {"id": d["id"], "text": d["text"]} for d in indexed_data
            ]

        self.se = SearchEngine(model="bm25").index(pretokenized_indexed_data)

    def search(self, node: dict, cutoff: int):
        if self.tokenizer is not None:
            raw_result = self.se.search(self.tokenizer(node["text"]), cutoff=cutoff)
            return self.indexed_data[raw_result["id"]]
        else:
            return self.se.search(node["text"], cutoff=cutoff)

    def bsearch(self, node_list: List[dict], cutoff: int):
        LOGGER.info("preparing")
        queries = [
            {"id": i, "text": node["text"]}
            for i, node in zip(range(len(node_list)), node_list)
        ]
        if self.tokenizer is not None:
            delayed_tokenizer = delayed(self.tokenizer)
            queries = Parallel(n_jobs=32)(delayed_tokenizer(q) for q in queries)
        result_dict = self.se.bsearch(queries=queries, cutoff=cutoff, batch_size=8192)
        LOGGER.info("got data")
        all_result = []
        for qid in range(len(queries)):
            result_ids_kv = list(result_dict[qid].items())
            # result_ids_kv = sorted(result_ids_kv, key=lambda x: -x[1])
            qdocs = []

            for i in range(len(result_ids_kv)):
                rdoc_id, rdoc_score = result_ids_kv[i]
                if i > 0:
                    assert rdoc_score <= result_ids_kv[i - 1][1]

                rdoc = self.indexed_data[rdoc_id]
                assert rdoc["id"] == rdoc_id
                qdocs.append(rdoc)

            all_result.append(qdocs)

        return all_result
