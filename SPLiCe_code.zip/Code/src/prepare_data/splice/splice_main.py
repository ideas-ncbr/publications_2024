from ...utils.prepare_parameters import (
    Parameter,
    prepare_config_dict,
    pcheck_not_none,
    check_config,
    dump_parameters,
)
from ..utils.record_loader import read_one_record
import mlxu
import logging
import sys
from ...utils.multi_logging import MultiLogger
from ..utils.file_utils import DatasetWriter
import json
from .retrievers.base_retriever import IndexedData
from .retrievers.get_retriver import get_retriever
from .stats import DatasetStats, ExampleStats
import tqdm
from queue import Queue
from typing import List, Optional
import random
from datasets import load_dataset
from absl import app

LOGGER = logging.Logger("SPLiCe Main", level=logging.INFO)
LOGGER_HANDLER = logging.StreamHandler(sys.stderr)
LOGGER_HANDLER.setFormatter(
    logging.Formatter("[%(asctime)s] SPM [%(levelname)s] : %(message)s")
)
LOGGER.addHandler(LOGGER_HANDLER)
LOGGER = MultiLogger(basic_loggers=[print], advanced_loggers=[LOGGER])


def get_default_parameters():
    return [
        Parameter("source_dataset_mode", None, "hf|file; str", pcheck_not_none),
        Parameter("source_dataset", None, "name/path; str", pcheck_not_none),
        Parameter(
            "source_dataset_subset", None, "name, only for hf source_dataset_mode; str"
        ),
        Parameter(
            "source_dataset_split", None, "name, only for hf source_dataset_mode; str"
        ),
        Parameter("destination_dataset_path", None, "path; str", pcheck_not_none),
        Parameter("content_field", None, "field with text; str", pcheck_not_none),
        Parameter(
            "min_len_in_chars", 128, "filter out shorter docs; int", pcheck_not_none
        ),
        Parameter(
            "aggregate_mode", None, "bm25|repo|random|plain; str", pcheck_not_none
        ),
        Parameter("topk", None, "; int", pcheck_not_none),
        Parameter("topk_sample", None, "what subset of topk to sample; int"),
        Parameter(
            "reverse_tree",
            None,
            "whether to reverse the alg tree; bool",
            pcheck_not_none,
        ),
        Parameter(
            "random_shuffle_tree",
            None,
            "whether to shuffle the alg tree; bool",
            pcheck_not_none,
        ),
        Parameter(
            "prefilter_max_doc_chars",
            None,
            "max chars in one input doc; int",
            pcheck_not_none,
        ),
        Parameter(
            "max_doc_chars", None, "max chars in one example; int", pcheck_not_none
        ),
        Parameter(
            "randomize_max_doc_chars_lower_bound",
            None,
            "if not None then randomize max doc chars with a specified lower bound and max_doc_chars as the upper bound; int",
        ),
        Parameter(
            "max_total_chars",
            None,
            "max chars in generated dataset; int",
            pcheck_not_none,
        ),
        Parameter(
            "precompute",
            None,
            "whether to precompute neighbors (use only with bm25); bool",
            pcheck_not_none,
        ),
        Parameter(
            "stop_fraction",
            None,
            "stop after generating this fraction of chars; float",
            pcheck_not_none,
        ),
        Parameter("cutoff_base", 100, "nn_search_base; int", pcheck_not_none),
        Parameter(
            "take_char_prefix",
            None,
            "how many chars to load from the dataset; int",
            pcheck_not_none,
        ),
        Parameter("tokenizer_path", None, "; str"),
        Parameter("seed", 42, "; int"),
        Parameter("noise", 0.0, "amount of random noise in preparation process")
    ]


FLAGS, _ = mlxu.define_flags_with_default(
    splice_main=prepare_config_dict(get_default_parameters(), check_parameters=False)
)


def aggregate_docs(
    docs,
    topk,
    max_doc_chars,
    mode,
    max_total_chars,
    min_len_in_chars,
    precompute,
    stop_fraction,
    random_shuffle_tree,
    reverse_tree,
    topk_sample,
    tokenizer_path,
    cutoff_base,
    randomize_max_doc_chars_lower_bound,
    procedure_noise,
):
    LOGGER.info(f"reverse_tree {reverse_tree} topk_sample {topk_sample}")
    indexed_data = IndexedData(data=docs)
    LOGGER.info(f"Total number of documents: {len(indexed_data)}")

    retriever = get_retriever(
        mode=mode, indexed_data=indexed_data, tokenizer_path=tokenizer_path
    )

    def get_cutoff(marked_fraction: float):
        return int(cutoff_base / (1 - min(marked_fraction, 0.8)))

    if precompute:
        indexed_data.precompute_nn(
            retriever=retriever, cutoff=get_cutoff(1.0 - stop_fraction)
        )

    resulting_dataset = []
    documents_created = 0
    characters_added = 0

    def length_within_bounds(node_text: str, total_doc_length: int):
        return len(node_text) + total_doc_length <= max_doc_chars

    progress_bar = tqdm.tqdm(total=max_total_chars, desc="Gathering docs")

    dataset_stats = DatasetStats()

    for root_node in indexed_data.iter_unmarked():
        if characters_added >= max_total_chars:
            break
        if indexed_data.get_marked_fraction() > stop_fraction:
            LOGGER.info(f"Visited {stop_fraction} of documents, stopping")
            break

        assert root_node["id"] not in indexed_data.marked

        q = Queue()
        indexed_data.mark_data(root_node)
        q.put(root_node)

        resulting_tree = []
        if randomize_max_doc_chars_lower_bound is None:
            total_doc_length = 0
        else:
            total_doc_length = random.randint(
                0, max_doc_chars - randomize_max_doc_chars_lower_bound
            )
        to_unmark = []
        example_stats = ExampleStats(indexed_data)

        while not q.empty():
            node = q.get()
            node_text = node["text"]
            if length_within_bounds(node_text, total_doc_length):
                resulting_tree.append(node_text)
                total_doc_length += len(node_text)

                cutoff = get_cutoff(indexed_data.get_marked_fraction())

                example_stats.update(node)

                if procedure_noise > 0:
                    should_use_random_next = random.random() < procedure_noise
                else:
                    should_use_random_next = False

                if should_use_random_next:
                    LOGGER.info("Noisy")
                    num_candidates = len(indexed_data)
                    for _ in range(100):
                        candidate_id = random.randint(0, num_candidates - 1)
                        if not indexed_data.is_data_marked(indexed_data[candidate_id]):
                            LOGGER.info("success")
                            break
                    candidate = indexed_data[candidate_id]
                    next_nodes = [candidate]
                else:
                    LOGGER.info("Non noisy")
                    if precompute:
                        next_nodes = indexed_data.get_precomputed_nn(node)
                    else:
                        next_nodes = retriever.search(node, cutoff=cutoff)

                descendants = []
                for nn in next_nodes:
                    if len(descendants) >= topk:
                        break
                    if not indexed_data.is_data_marked(nn):
                        descendants.append(nn)

                random.shuffle(descendants)

                if topk_sample is not None:
                    descendants = descendants[:topk_sample]

                if len(descendants) < topk:
                    LOGGER.debug(
                        f"Not enough descendants! got {len(descendants)} but wanted {topk}, cutoff is {cutoff}"
                    )

                for d in descendants:
                    assert not indexed_data.is_data_marked(d)
                    d_text = d["text"]
                    if length_within_bounds(d_text, total_doc_length):
                        indexed_data.mark_data(d)
                        q.put(d)
            else:
                to_unmark.append(node)

        for tu in to_unmark:
            indexed_data.unmark_data(tu)

        def merge_docs(docs):
            return "\n".join(docs)

        if random_shuffle_tree:
            random.shuffle(resulting_tree)

        doc_string = merge_docs(resulting_tree)
        if len(doc_string) >= min_len_in_chars:
            assert len(doc_string) <= max_doc_chars + 2 * len(resulting_tree)
            if not reverse_tree:
                resulting_dataset.append(doc_string)
            else:
                resulting_dataset.append(merge_docs(resulting_tree[::-1]))
            progress_bar.update(len(doc_string))
            characters_added += len(doc_string)
            LOGGER.debug(f"Number of documents created: {documents_created}")
            LOGGER.debug(f"Number of characters added: {characters_added}")
            LOGGER.debug(f"Number of documents visited: {len(indexed_data.marked)}")
            documents_created += 1

            dataset_stats.update(example_stats)

    ds_summary = dataset_stats.create_summary()
    LOGGER.info(f"DatasetStats: {json.dumps(ds_summary, indent=2)}")
    LOGGER.info(f"Number of documents created: {documents_created}")
    LOGGER.info(f"Number of characters added: {characters_added}")
    LOGGER.info(f"Number of documents visited: {len(indexed_data.marked)}")

    return resulting_dataset, {
        "ds_stats": ds_summary,
        "docs_created": documents_created,
        "characters_added": characters_added,
        "documents visited": len(indexed_data.marked),
        "vis_frac": indexed_data.get_marked_fraction(),
    }


def get_records_from_dataset(
    ds_mode: str,
    ds_path: str,
    ds_subset: Optional[str],
    ds_split: Optional[str],
    topk: int,
    max_doc_chars: int,
    aggregate_mode: int,
    content_field: str,
    min_len_in_chars: int,
    max_total_chars,
    precompute: int,
    stop_fraction: float,
    prefilter_max_doc_chars: int,
    random_shuffle_tree: bool,
    reverse_tree: bool,
    topk_sample: int,
    take_char_prefix: Optional[int],
    tokenizer_path: Optional[str],
    cutoff_base: int,
    randomize_max_doc_chars_lower_bound: int,
    procedure_noise: float,
):
    # assert max_doc_chars >= prefilter_max_doc_chars
    LOGGER.info(
        f"Loading mode:{ds_mode} path:{ds_path} subset:{ds_subset} split:{ds_split}"
    )
    if ds_mode == "hf":
        assert False, "Not supported"
        dataset = load_dataset(
            ds_path,
            data_dir=ds_subset,
            split=ds_split,
            # cache_dir="./hf_tmp_cache",
        )
        LOGGER.info(f"Dataset downloaded number of records is {len(dataset)}")
        dataset = dataset.select_columns(
            [content_field, "max_stars_repo_path", "max_stars_repo_name"]
        )
        LOGGER.info(f"Dataset columns selected")
        df = dataset.to_pandas()
        LOGGER.info(f"Dataset converted to pandas")
        result = df.to_dict(orient="records")
        result = [
            {
                "repo_name": dct["max_stars_repo_name"],
                "repo_path": dct["max_stars_repo_path"],
                "text": dct[content_field],
            }
            for dct in result
        ]
    elif ds_mode == "file":
        assert ds_subset is None
        assert ds_split is None

        result = []
        with mlxu.open_file(ds_path, "r") as f:
            total_chars = 0
            while True:
                d = read_one_record(f)
                if d is not None:
                    new_d = {}
                    new_d["repo_name"] = d.get("max_stars_repo_name", None)
                    new_d["repo_path"] = d.get("max_stars_repo_path", None)
                    new_d["text"] = d[content_field]

                    if (
                        len(new_d["text"]) >= min_len_in_chars
                        and len(new_d["text"]) <= prefilter_max_doc_chars
                    ):
                        result.append(new_d)
                        total_chars += len(new_d["text"])
                        if (
                            take_char_prefix is not None
                            and total_chars >= take_char_prefix
                        ):
                            break

                else:
                    break
    else:
        raise ValueError(f"mode {ds_mode} not supported")

    LOGGER.info(
        f"After filtering has {len(result)} records and {total_chars} chars."
        f"That is around {total_chars/1e9} GB"
    )

    random.shuffle(result)

    LOGGER.info("Aggregating")
    result, stats = aggregate_docs(
        result,
        topk=topk,
        max_doc_chars=max_doc_chars,
        mode=aggregate_mode,
        max_total_chars=max_total_chars,
        min_len_in_chars=min_len_in_chars,
        precompute=precompute,
        stop_fraction=stop_fraction,
        random_shuffle_tree=random_shuffle_tree,
        reverse_tree=reverse_tree,
        topk_sample=topk_sample,
        tokenizer_path=tokenizer_path,
        cutoff_base=cutoff_base,
        randomize_max_doc_chars_lower_bound=randomize_max_doc_chars_lower_bound,
        procedure_noise=procedure_noise,
    )

    LOGGER.info("Finalizing")
    random.shuffle(result)

    result = [{"text": txt} for txt in result]

    return result, stats


def main(_):
    check_config(FLAGS.splice_main, get_default_parameters())
    random.seed(FLAGS.splice_main.seed)
    assert FLAGS.splice_main.destination_dataset_path is not None

    all_results, stats = get_records_from_dataset(
        ds_mode=FLAGS.splice_main.source_dataset_mode,
        ds_path=FLAGS.splice_main.source_dataset,
        ds_subset=FLAGS.splice_main.source_dataset_subset,
        ds_split=FLAGS.splice_main.source_dataset_split,
        topk=FLAGS.splice_main.topk,
        max_doc_chars=FLAGS.splice_main.max_doc_chars,
        aggregate_mode=FLAGS.splice_main.aggregate_mode,
        content_field=FLAGS.splice_main.content_field,
        min_len_in_chars=FLAGS.splice_main.min_len_in_chars,
        max_total_chars=FLAGS.splice_main.max_total_chars,
        precompute=FLAGS.splice_main.precompute,
        stop_fraction=FLAGS.splice_main.stop_fraction,
        prefilter_max_doc_chars=FLAGS.splice_main.prefilter_max_doc_chars,
        random_shuffle_tree=FLAGS.splice_main.random_shuffle_tree,
        reverse_tree=FLAGS.splice_main.reverse_tree,
        topk_sample=FLAGS.splice_main.topk_sample,
        take_char_prefix=FLAGS.splice_main.take_char_prefix,
        tokenizer_path=FLAGS.splice_main.tokenizer_path,
        cutoff_base=FLAGS.splice_main.cutoff_base,
        randomize_max_doc_chars_lower_bound=FLAGS.splice_main.randomize_max_doc_chars_lower_bound,
        procedure_noise=FLAGS.splice_main.noise,
    )

    LOGGER.info("Finished processing partitions. Now saving to GCS.")
    result_path = FLAGS.splice_main.destination_dataset_path
    LOGGER.info("Starting saving to: " + result_path)

    dump_parameters(
        FLAGS.splice_main,
        get_default_parameters(),
        result_path + ".meta.json",
        param_add_prefix="splice_main.",
        additional_data=stats,
    )

    with DatasetWriter(
        result_path,
        expected_chars=stats["characters_added"],
        text_field="text",
        add_time_stamp=False,
    ) as dw:
        for r in all_results:
            dw.add(r)

    LOGGER.info("Finished saving to GCS. All results len: " + str(len(all_results)))
    LOGGER.info("Saved to: " + result_path)


if __name__ == "__main__":
    app.run(main)
