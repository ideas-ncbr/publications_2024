from absl import flags, app
import mlxu
from typing import List, Any, Dict
import random
import json
import logging
import sys
import functools
from ..utils.file_utils import BuffferedFile
import io
from ...utils.multi_logging import MultiLogger
from ...utils.prepare_parameters import (
    Parameter,
    prepare_config_dict,
    pcheck_not_none,
    check_config,
    dump_parameters,
)
from ..utils.file_utils import LineFile, DatasetWriter
from ..utils.record_loader import read_one_record
from datetime import datetime
from datasets import load_dataset


def get_default_parameters():
    return [
        Parameter(
            "load_dataset_kwargs",
            None,
            "path to hf dataset; Dict[str, Any]",
            pcheck_not_none,
        ),
        Parameter("content_field", None, "field with text; str", pcheck_not_none),
        Parameter(
            "dest_path", None, "output path for jsonl dataset; str", pcheck_not_none
        ),
        Parameter("max_chars", None, "max num chars to extract; int", pcheck_not_none),
    ]


FLAGS, _ = mlxu.define_flags_with_default(
    hf_to_jsonl=prepare_config_dict(get_default_parameters(), check_parameters=False)
)
File = Any


LOGGER = logging.Logger("HF to jsonl", level=logging.INFO)
LOGGER_HANDLER = logging.StreamHandler(sys.stderr)
LOGGER_HANDLER.setFormatter(
    logging.Formatter("[%(asctime)s] HtJ [%(levelname)s] : %(message)s")
)
LOGGER.addHandler(LOGGER_HANDLER)
LOGGER = MultiLogger(basic_loggers=[print], advanced_loggers=[LOGGER])


def hf_to_jsonl(
    load_dataset_kwargs: Dict[str, Any],
    content_field: str,
    dest_path: str,
    max_chars: int,
):
    ds = load_dataset(**load_dataset_kwargs)
    ds = iter(ds)
    total_chars = 0
    with DatasetWriter(
        dest_path,
        expected_chars=max_chars,
        text_field=content_field,
        add_time_stamp=False,
    ) as dw:
        for record in ds:
            dw.add(record)
            total_chars = dw.written_chars
            if dw.is_full():
                break
    return {"loaded_chars": total_chars}


def main(_):
    check_config(FLAGS.hf_to_jsonl, get_default_parameters())
    stats = hf_to_jsonl(
        load_dataset_kwargs=FLAGS.hf_to_jsonl.load_dataset_kwargs,
        content_field=FLAGS.hf_to_jsonl.content_field,
        dest_path=FLAGS.hf_to_jsonl.dest_path,
        max_chars=FLAGS.hf_to_jsonl.max_chars,
    )

    dump_parameters(
        FLAGS.hf_to_jsonl,
        get_default_parameters(),
        FLAGS.hf_to_jsonl.dest_path + ".meta.json",
        "hf_to_jsonl.",
        stats,
    )

    LOGGER.info(f"Done")


if __name__ == "__main__":
    app.run(main)
