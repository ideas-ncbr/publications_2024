from absl import flags, app
import mlxu
from typing import List, Any, Tuple
import random
import json
import logging
import sys
import functools
from ..utils.file_utils import BuffferedFile
import io
from ...utils.multi_logging import MultiLogger
from ...utils.prepare_parameters import (
    Parameter,
    prepare_config_dict,
    pcheck_not_none,
    check_config,
    dump_parameters,
)
from ..utils.file_utils import LineFile
from ..utils.record_loader import read_one_record
from datetime import datetime
from transformers import AutoTokenizer


def get_default_parameters():
    return [
        Parameter(
            "dataset_paths", None, "paths to jsonl datasets; List[str]", pcheck_not_none
        ),
        Parameter(
            "source_fields",
            None,
            "for each dataset name of the field with text; List[str]",
            pcheck_not_none,
        ),
        Parameter(
            "fields_to_retain",
            None,
            "list of fields that should be preserved in addition to source_fields; List[str]",
        ),
        Parameter(
            "destination_field",
            "text",
            "source_fields -> destination_field; str",
            pcheck_not_none,
        ),
        Parameter(
            "origin_field_name",
            "source_dataset",
            "field for adding information about data origin; str",
            pcheck_not_none,
        ),
        Parameter("origin_to_add", None, "data origins to add; Optional[List[str]]"),
        Parameter(
            "proportions",
            None,
            "for each dataset proportion of the data it should occupy; Optional[List[float]]",
            lambda x: x is None or abs(sum(x) - 1.0) <= 1e-4,
        ),
        Parameter("max_chars", None, "max total chars to load; int"),
        Parameter(
            "max_tokens",
            None,
            "(hf_tokenizer_path, max_num_tokens); Optional (str, int)",
        ),
        Parameter(
            "preshuffle_files",
            False,
            "preload and shuffle the datasets; bool",
            pcheck_not_none,
        ),
        Parameter(
            "random_shuffle",
            True,
            "shuffle the data before saving; bool",
            pcheck_not_none,
        ),
        Parameter(
            "destination_path", None, "path to save the data; str", pcheck_not_none
        ),
        Parameter("seed", 42, "seed; int", pcheck_not_none),
    ]


FLAGS, _ = mlxu.define_flags_with_default(
    merge_ds=prepare_config_dict(get_default_parameters(), check_parameters=False)
)
File = Any


LOGGER = logging.Logger("Dataset merge", level=logging.INFO)
LOGGER_HANDLER = logging.StreamHandler(sys.stderr)
LOGGER_HANDLER.setFormatter(
    logging.Formatter("[%(asctime)s] DSM [%(levelname)s] : %(message)s")
)
LOGGER.addHandler(LOGGER_HANDLER)
LOGGER = MultiLogger(basic_loggers=[print], advanced_loggers=[LOGGER])


def preshuffle_file(file):
    raw_content = file.read()
    with io.StringIO(raw_content) as io_file:
        content = io_file.readlines()
    random.shuffle(content)
    return LineFile(content)


def preshuffle_files(files: List[File]):
    result = []
    for fid, f in enumerate(files):
        LOGGER.info(f"Processing file {fid}")
        result.append(preshuffle_file(f))

    return result


def load_proportionally(
    files: List[File],
    source_fields: List[str],
    destination_field: str,
    proportions: List[float],
    max_chars: int,
    origin_field_name: str,
    origin_to_add: List[str],
    fields_to_retain: List[str] = None,
    max_tokens: Tuple[str, int] = None,
):
    assert len(files) == len(source_fields)
    assert proportions is None or len(files) == len(proportions)
    assert len(files) == len(origin_to_add)
    assert max_tokens is None or max_chars is None
    assert max_tokens is not None or max_chars is not None

    if proportions is None:
        proportions = [1.0] * len(files)
        full_merge_mode = True
    else:
        full_merge_mode = False

    LOGGER.info(
        f"Starting proportional loading with source_fields: {source_fields}, destination_field: {destination_field}, proportions {proportions}, max_chars {max_chars}, origin_field_name {origin_field_name}, origin_to_add {origin_to_add}"
    )
    units_per_file = [0 for _ in proportions]
    finished_file = [False for _ in proportions]
    total_loaded_units = 0

    if max_tokens is not None:
        tokenizer_path, max_tokens = max_tokens
        tokenizer = AutoTokenizer.from_pretrained(tokenizer_path, use_fast=False)

    def get_underrepresented_file_id():
        nonlocal units_per_file
        nonlocal total_loaded_units
        nonlocal finished_file
        smallest_diff = 2.0
        prop_sum = 0.0
        smallest_id = None
        for id, (upf, req_props, fin_file) in enumerate(
            zip(units_per_file, proportions, finished_file)
        ):
            curr_prop = upf / max(total_loaded_units, 1)
            prop_sum += curr_prop
            diff = curr_prop - req_props
            if diff < smallest_diff and not fin_file:
                smallest_id = id
                smallest_diff = diff

        assert smallest_diff <= 1e-4 or prop_sum == 0.0
        assert abs(prop_sum - 1.0) <= 1e-4 or prop_sum == 0.0
        assert smallest_id is not None
        return smallest_id

    record_list = []
    while True:
        fid = get_underrepresented_file_id()

        assert not finished_file[fid]

        dict_raw_record = read_one_record(files[fid])
        if dict_raw_record is None:
            if not full_merge_mode:
                LOGGER.warning(
                    f"Finished prematurely due to end of source {origin_to_add[fid]}"
                )
                break
            else:
                finished_file[fid] = True
                acc = True
                for ff in finished_file:
                    acc = acc and ff
                if acc:
                    LOGGER.info(f"All files finished")
                    break

        else:
            record = {}
            record[destination_field] = dict_raw_record[source_fields[fid]]
            record[origin_field_name] = origin_to_add[fid]

            if fields_to_retain is not None:
                for ftr in fields_to_retain:
                    record[ftr] = dict_raw_record[ftr]
            else:
                for ftr in dict_raw_record.keys():
                    if (
                        ftr != source_fields[fid]
                        and ftr != destination_field
                        and ftr != origin_field_name
                    ):
                        record[ftr] = dict_raw_record[ftr]

            if max_chars is not None:
                num_units = len(record[destination_field])
                max_units = max_chars
            elif max_tokens is not None:
                num_units = len(
                    tokenizer.encode(
                        record[destination_field], add_special_tokens=False
                    )
                )
                max_units = max_tokens
            else:
                raise ValueError("No supported unit type (char, token) provided")

            record_list.append(record)
            units_per_file[fid] += num_units
            total_loaded_units += num_units
            if total_loaded_units >= max_units:
                LOGGER.info(
                    f"Finished due to unit limit {max_units} vs {total_loaded_units}"
                )
                break

    final_props = [upf / total_loaded_units for upf in units_per_file]
    LOGGER.info(f"Requested proportions {proportions} vs actual {final_props}")
    LOGGER.info(f"Loaded {len(record_list)} records")

    return record_list


def main(_):
    check_config(FLAGS.merge_ds, get_default_parameters())
    assert FLAGS.merge_ds.max_chars is None or FLAGS.merge_ds.max_tokens is None
    random.seed(FLAGS.merge_ds.seed)
    LOGGER.info(f"Opening files {FLAGS.merge_ds.dataset_paths}")
    files = [mlxu.open_file(p, "r") for p in FLAGS.merge_ds.dataset_paths]

    if FLAGS.merge_ds.preshuffle_files:
        LOGGER.info(f"Loading to memory and preshuffling")
        files = preshuffle_files(files)
    else:
        LOGGER.warning(
            f"NO PRESHUFFLING APPLIED, make sure that the source datasets are shuffled"
        )

    origin_to_add = (
        FLAGS.merge_ds.dataset_paths
        if FLAGS.merge_ds.origin_to_add is None
        else FLAGS.merge_ds.origin_to_add
    )

    record_list = load_proportionally(
        files=files,
        source_fields=FLAGS.merge_ds.source_fields,
        destination_field=FLAGS.merge_ds.destination_field,
        proportions=FLAGS.merge_ds.proportions,
        max_chars=FLAGS.merge_ds.max_chars,
        max_tokens=FLAGS.merge_ds.max_tokens,
        origin_field_name=FLAGS.merge_ds.origin_field_name,
        origin_to_add=origin_to_add,
        fields_to_retain=FLAGS.merge_ds.fields_to_retain,
    )

    LOGGER.info(f"Shuffling")
    if FLAGS.merge_ds.random_shuffle:
        random.shuffle(record_list)

    destination_path = FLAGS.merge_ds.destination_path

    LOGGER.info(f"Saving to {destination_path}")
    print(f"Saving to {destination_path}")
    dump_parameters(
        FLAGS.merge_ds,
        get_default_parameters(),
        destination_path + ".meta.json",
        param_add_prefix="merge.",
    )

    dest_f = BuffferedFile(destination_path)

    for r in record_list:
        dest_f.write(json.dumps(r) + "\n")

    dest_f.close()

    for f in files:
        f.close()

    LOGGER.info(f"Done")


if __name__ == "__main__":
    app.run(main)
