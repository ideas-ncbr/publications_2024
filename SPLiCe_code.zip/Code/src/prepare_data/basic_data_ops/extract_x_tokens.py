from absl import flags, app
import mlxu
from typing import List, Any
import random
import json
import logging
import sys
import functools
from ..utils.file_utils import BuffferedFile
import io
from ...utils.multi_logging import MultiLogger
from ...utils.prepare_parameters import (
    Parameter,
    prepare_config_dict,
    pcheck_not_none,
    check_config,
    dump_parameters,
)
from ..utils.file_utils import LineFile
from ..utils.record_loader import read_one_record
from datetime import datetime


def get_default_parameters():
    return [
        Parameter("dataset_path", None, "path to jsonl dataset; str", pcheck_not_none),
        Parameter("content_field", None, "path to jsonl dataset; str", pcheck_not_none),
        Parameter("max_tokens", None, "num tokens to extract; int", pcheck_not_none),
        Parameter("tokenizer_path", None, "path to tokenizer; int", pcheck_not_none),
    ]


FLAGS, _ = mlxu.define_flags_with_default(
    merge_ds=prepare_config_dict(get_default_parameters(), check_parameters=False)
)
File = Any


LOGGER = logging.Logger("Dataset merge", level=logging.INFO)
LOGGER_HANDLER = logging.StreamHandler(sys.stderr)
LOGGER_HANDLER.setFormatter(
    logging.Formatter("[%(asctime)s] DSM [%(levelname)s] : %(message)s")
)
LOGGER.addHandler(LOGGER_HANDLER)
LOGGER = MultiLogger(basic_loggers=[print], advanced_loggers=[LOGGER])


def preshuffle_file(file):
    raw_content = file.read()
    with io.StringIO(raw_content) as io_file:
        content = io_file.readlines()
    random.shuffle(content)
    return LineFile(content)


def preshuffle_files(files: List[File]):
    result = []
    for fid, f in enumerate(files):
        LOGGER.info(f"Processing file {fid}")
        result.append(preshuffle_file(f))

    return result


def load_proportionally(
    files: List[File],
    source_fields: List[str],
    destination_field: str,
    char_proportions: List[float],
    max_chars: int,
    origin_field_name: str,
    origin_to_add: List[str],
    fields_to_retain: List[str] = [],
):
    assert len(files) == len(source_fields)
    assert char_proportions is None or len(files) == len(char_proportions)
    assert len(files) == len(origin_to_add)

    if char_proportions is None:
        char_proportions = [1.0] * len(files)
        full_merge_mode = True
    else:
        full_merge_mode = False

    LOGGER.info(
        f"Starting proportional loading with source_fields: {source_fields}, destination_field: {destination_field}, char_proportions {char_proportions}, max_chars {max_chars}, origin_field_name {origin_field_name}, origin_to_add {origin_to_add}"
    )
    chars_per_file = [0 for _ in char_proportions]
    finished_file = [False for _ in char_proportions]
    total_loaded_chars = 0

    def get_underrepresented_file_id():
        nonlocal chars_per_file
        nonlocal total_loaded_chars
        nonlocal finished_file
        smallest_diff = 2.0
        prop_sum = 0.0
        smallest_id = None
        for id, (cpf, req_props, fin_file) in enumerate(
            zip(chars_per_file, char_proportions, finished_file)
        ):
            curr_prop = cpf / max(total_loaded_chars, 1)
            prop_sum += curr_prop
            diff = curr_prop - req_props
            if diff < smallest_diff and not fin_file:
                smallest_id = id
                smallest_diff = diff

        assert smallest_diff <= 1e-4 or prop_sum == 0.0
        assert abs(prop_sum - 1.0) <= 1e-4 or prop_sum == 0.0
        assert smallest_id is not None
        return smallest_id

    record_list = []
    while True:
        fid = get_underrepresented_file_id()

        assert not finished_file[fid]

        dict_raw_record = read_one_record(files[fid])
        if dict_raw_record is None:
            if not full_merge_mode:
                LOGGER.warning(
                    f"Finished prematurely due to end of source {origin_to_add[fid]}"
                )
                break
            else:
                finished_file[fid] = True
                acc = True
                for ff in finished_file:
                    acc = acc and ff
                if acc:
                    LOGGER.info(f"All files finished")
                    break

        else:
            record = {}
            record[destination_field] = dict_raw_record[source_fields[fid]]
            record[origin_field_name] = origin_to_add[fid]
            for ftr in fields_to_retain:
                record[ftr] = dict_raw_record[ftr]

            num_chars = len(record[destination_field])

            record_list.append(record)
            chars_per_file[fid] += num_chars
            total_loaded_chars += num_chars
            if total_loaded_chars >= max_chars:
                LOGGER.info(
                    f"Finished due to char limit {max_chars} vs {total_loaded_chars}"
                )
                break

    final_props = [cpf / total_loaded_chars for cpf in chars_per_file]
    LOGGER.info(f"Requested proportions {char_proportions} vs actual {final_props}")
    LOGGER.info(f"Loaded {len(record_list)} records")

    return record_list


def main(_):
    check_config(FLAGS.merge_ds, get_default_parameters())
    random.seed(FLAGS.merge_ds.seed)
    LOGGER.info(f"Opening files {FLAGS.merge_ds.dataset_paths}")
    files = [mlxu.open_file(p, "r") for p in FLAGS.merge_ds.dataset_paths]

    if FLAGS.merge_ds.preshuffle_files:
        LOGGER.info(f"Loading to memory and preshuffling")
        files = preshuffle_files(files)
    else:
        LOGGER.warning(
            f"NO PRESHUFFLING APPLIED, make sure that the source datasets are shuffled"
        )

    origin_to_add = (
        FLAGS.merge_ds.dataset_paths
        if FLAGS.merge_ds.origin_to_add is None
        else FLAGS.merge_ds.origin_to_add
    )

    record_list = load_proportionally(
        files=files,
        source_fields=FLAGS.merge_ds.source_fields,
        destination_field=FLAGS.merge_ds.destination_field,
        char_proportions=FLAGS.merge_ds.char_proportions,
        max_chars=FLAGS.merge_ds.max_chars,
        origin_field_name=FLAGS.merge_ds.origin_field_name,
        origin_to_add=origin_to_add,
        fields_to_retain=FLAGS.merge_ds.fields_to_retain,
    )

    LOGGER.info(f"Shuffling")
    if FLAGS.merge_ds.random_shuffle:
        random.shuffle(record_list)

    destination_path = FLAGS.merge_ds.destination_path

    LOGGER.info(f"Saving to {destination_path}")
    print(f"Saving to {destination_path}")
    dump_parameters(
        FLAGS.merge_ds,
        get_default_parameters(),
        destination_path + ".meta.json",
        param_add_prefix="merge.",
    )

    dest_f = BuffferedFile(destination_path)

    for r in record_list:
        dest_f.write(json.dumps(r) + "\n")

    dest_f.close()

    for f in files:
        f.close()

    LOGGER.info(f"Done")


if __name__ == "__main__":
    app.run(main)
