from absl import flags, app
import mlxu
from typing import List, Any
import random
import json
import logging
import sys
import functools
from ..utils.file_utils import BuffferedFile, LineFile
from datetime import datetime
import io
import tqdm
import math
import os
from ...utils.prepare_parameters import (
    Parameter,
    prepare_config_dict,
    pcheck_not_none,
    check_config,
    dump_parameters,
)
from ..utils.record_loader import read_one_record
from ...utils.multi_logging import MultiLogger
import transformers
from joblib import Parallel, delayed


def get_default_parameters():
    return [
        Parameter(
            "dataset_path", None, "paths to jsonl datasets; str", pcheck_not_none
        ),
        Parameter("content_field", None, "; str", pcheck_not_none),
        Parameter("tokenizer_name", None, "; str", pcheck_not_none),
        Parameter("tokenizer_path", None, "; str", pcheck_not_none),
        Parameter("max_chars_to_load", None, "; int", pcheck_not_none),
        Parameter("parallel_tokenizers", None, "; int", pcheck_not_none),
    ]


FLAGS, _ = mlxu.define_flags_with_default(
    count_tokens=prepare_config_dict(get_default_parameters(), check_parameters=False)
)

LOGGER = logging.Logger("Dataset split", level=logging.INFO)
LOGGER_HANDLER = logging.StreamHandler(sys.stderr)
LOGGER_HANDLER.setFormatter(
    logging.Formatter("[%(asctime)s] DSS [%(levelname)s] : %(message)s")
)
LOGGER.addHandler(LOGGER_HANDLER)
LOGGER = MultiLogger(basic_loggers=[print], advanced_loggers=[LOGGER])


def count_tokens(
    ds_path: str,
    tokenizer_name: str,
    tokenizer_path: str,
    content_field: str,
    max_chars_to_load: int,
    parallel_tokenizers: int,
):
    tokenizer = getattr(transformers, tokenizer_name).from_pretrained(
        tokenizer_path, use_fast=False
    )
    stats = {
        "total_tokens": 0,
        "total_chars": 0,
        "chars_per_token": 0,
    }

    def update_stats(batch, stats):
        stats = dict(**stats)

        @delayed
        def count_tokens_chars(text):
            tokens = tokenizer.encode(text)
            return len(tokens), len(text)

        results = Parallel(n_jobs=parallel_tokenizers)(
            count_tokens_chars(t) for t in batch
        )
        for r in results:
            stats["total_tokens"] += r[0]
            stats["total_chars"] += r[1]

        stats["chars_per_token"] = stats["total_chars"] / stats["total_tokens"]
        return stats

    total_chars = 0
    with mlxu.open_file(ds_path, "r") as f:
        result = read_one_record(f)
        step = 0
        batch = []
        with tqdm.tqdm(total=max_chars_to_load, desc="Chars loaded") as pbar:
            while result is not None:
                content = result[content_field]
                batch.append(content)

                if len(batch) >= 1000 * parallel_tokenizers:
                    stats = update_stats(batch, stats)
                    pbar.write(json.dumps(stats))
                    batch = []

                total_chars += len(content)
                pbar.update(len(content))
                if total_chars >= max_chars_to_load:
                    break
                step += 1
                result = read_one_record(f)

        if len(batch) != 0:
            stats = update_stats(batch, stats)
            batch = []

    return stats


def get_file_lines(file_path: str):
    with mlxu.open_file(file_path, "r") as f:
        lines = f.readlines()

    for l in lines:
        assert len(l) > 0

    LOGGER.info(f"Loaded {len(lines)} lines")

    return lines


def main(_):
    check_config(FLAGS.count_tokens, get_default_parameters())

    stats = count_tokens(
        ds_path=FLAGS.count_tokens.dataset_path,
        content_field=FLAGS.count_tokens.content_field,
        tokenizer_name=FLAGS.count_tokens.tokenizer_name,
        tokenizer_path=FLAGS.count_tokens.tokenizer_path,
        max_chars_to_load=FLAGS.count_tokens.max_chars_to_load,
        parallel_tokenizers=FLAGS.count_tokens.parallel_tokenizers,
    )
    dump_parameters(
        FLAGS.count_tokens,
        get_default_parameters(),
        FLAGS.count_tokens.dataset_path + ".count_tokens.json",
        "count_tokens",
        stats,
    )


if __name__ == "__main__":
    app.run(main)
