from absl import flags, app
import mlxu
from typing import List, Any
import random
import json
import logging
import sys
import functools
from ..utils.file_utils import BuffferedFile, LineFile
from datetime import datetime
import io
import tqdm
import math
import os
from ...utils.prepare_parameters import (
    Parameter,
    prepare_config_dict,
    pcheck_not_none,
    check_config,
    dump_parameters,
)
from ..utils.record_loader import read_one_record
from ...utils.multi_logging import MultiLogger


def get_default_parameters():
    return [
        Parameter(
            "dataset_path", None, "paths to jsonl datasets; str", pcheck_not_none
        ),
        Parameter("output_dir", None, "; str", pcheck_not_none),
        Parameter(
            "preshuffle",
            False,
            "whether to load and preshuffle file before splitting; bool",
        ),
        Parameter("content_field", "text", "field with text; str", pcheck_not_none),
        Parameter("split_every_n_chars", None, "; Optional[int]"),
        Parameter("split_proportions", None, "; Optional[float]"),
        Parameter("seed", 42, "seed; int", pcheck_not_none),
    ]


FLAGS, _ = mlxu.define_flags_with_default(
    split_ds=prepare_config_dict(get_default_parameters(), check_parameters=False)
)

LOGGER = logging.Logger("Dataset split", level=logging.INFO)
LOGGER_HANDLER = logging.StreamHandler(sys.stderr)
LOGGER_HANDLER.setFormatter(
    logging.Formatter("[%(asctime)s] DSS [%(levelname)s] : %(message)s")
)
LOGGER.addHandler(LOGGER_HANDLER)
LOGGER = MultiLogger(basic_loggers=[print], advanced_loggers=[LOGGER])


def split_dataset_to_parts(
    ds_file, ds_path: str, output_dir, split_every_n_chars: int, content_field: str
):

    LOGGER.info(
        f"Splitting {ds_path} to {output_dir} every {split_every_n_chars} using field {content_field}"
    )

    source_name = ds_path.split("/")[-1]

    def get_output_file(file_id):
        return os.path.join(output_dir, f"splitted/{file_id}.{source_name}.jsonl")

    cur_id = 0
    cur_chars = 0

    cur_file = get_output_file(cur_id)
    LOGGER.info(f"writting from {ds_path} to {cur_file}")
    cur_progress_bar = tqdm.tqdm(total=split_every_n_chars)
    file = BuffferedFile(path=cur_file)
    while True:
        record = read_one_record(ds_file)
        if record is None:
            break

        cur_chars += len(record[content_field])
        cur_progress_bar.update(len(record[content_field]))
        file.write(json.dumps(record) + "\n")
        if cur_chars >= split_every_n_chars:
            file.flush()
            file.close()
            LOGGER.info(f"Generated file {cur_file} with {cur_chars} chars")
            cur_chars = 0
            cur_id += 1
            cur_file = get_output_file(cur_id)
            cur_progress_bar = tqdm.tqdm(total=split_every_n_chars)
            file = BuffferedFile(path=cur_file)

    file.flush()
    file.close()
    LOGGER.info("Finished")


def get_file_lines(file_path: str):
    with mlxu.open_file(file_path, "r") as f:
        lines = f.readlines()

    for l in lines:
        assert len(l) > 0

    LOGGER.info(f"Loaded {len(lines)} lines")

    return lines


def main(_):
    check_config(FLAGS.split_ds, get_default_parameters())
    dump_parameters(
        FLAGS.split_ds,
        get_default_parameters(),
        os.path.join(
            FLAGS.split_ds.output_dir,
            f"{FLAGS.split_ds.dataset_path.split('/')[-1]}.split.meta.json",
        ),
        param_add_prefix="split_ds.",
    )
    random.seed(FLAGS.split_ds.seed)
    assert (
        FLAGS.split_ds.split_every_n_chars is None
        or FLAGS.split_ds.split_proportions is None
    )
    assert (
        FLAGS.split_ds.split_every_n_chars is not None
        or FLAGS.split_ds.split_proportions is not None
    )
    if FLAGS.split_ds.preshuffle:
        lines = get_file_lines(FLAGS.split_ds.dataset_path)

        LOGGER.info(f"Shuffling")
        random.shuffle(lines)
        ds_file = LineFile(line_list=lines)
    else:
        ds_file = mlxu.open_file(FLAGS.split_ds.dataset_path, "r")

    if FLAGS.split_ds.split_proportions is not None:
        total_chars = 0
        with mlxu.open_file(FLAGS.split_ds.dataset_path, "r") as f:
            while True:
                line = f.readline()
                if line is None or len(line) == 0:
                    break
                else:
                    total_chars += len(json.loads(line)[FLAGS.split_ds.content_field])

        split_every_n_chars = int(
            math.ceil(total_chars * FLAGS.split_ds.split_proportions) + 1
        )
    else:
        split_every_n_chars = FLAGS.split_ds.split_every_n_chars

    split_dataset_to_parts(
        ds_file=ds_file,
        ds_path=FLAGS.split_ds.dataset_path,
        content_field=FLAGS.split_ds.content_field,
        split_every_n_chars=split_every_n_chars,
        output_dir=FLAGS.split_ds.output_dir,
    )
    ds_file.close()


if __name__ == "__main__":
    app.run(main)
