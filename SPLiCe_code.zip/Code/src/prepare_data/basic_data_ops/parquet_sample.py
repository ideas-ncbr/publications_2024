import mlxu
from datasets import load_dataset
from typing import Optional, List
from absl import flags, app
import json
import numpy as np
import io
import pandas as pd
import requests
import tempfile
import random
import pyarrow as pa
import pyarrow.parquet as pq
import logging
import sys
import tqdm
from huggingface_hub import HfFileSystem
from ...utils.multi_logging import MultiLogger
from ..utils.file_utils import BuffferedFile, DatasetWriter
import functools
from ...utils.prepare_parameters import (
    Parameter,
    prepare_config_dict,
    pcheck_not_none,
    check_config,
    dump_parameters,
)

from datetime import datetime
import os

LOGGER = logging.Logger("Parquet dataset", level=logging.INFO)
LOGGER_HANDLER = logging.StreamHandler(sys.stdout)
LOGGER_HANDLER.setFormatter(
    logging.Formatter("[%(asctime)s] Parkiet [%(levelname)s] : %(message)s")
)
LOGGER.addHandler(LOGGER_HANDLER)
LOGGER = MultiLogger(basic_loggers=[print], advanced_loggers=[LOGGER])

FLAGS = flags.FLAGS


def get_default_parameters():
    return [
        Parameter("destination_path", None, "; str", pcheck_not_none),
        Parameter("dataset", None, "hugging face dataset ; str", pcheck_not_none),
        Parameter("source_field", None, "field with text ; str", pcheck_not_none),
        Parameter(
            "fields_to_retain",
            None,
            "fields to maintain except the text field ; List[str]",
            pcheck_not_none,
        ),
        Parameter(
            "num_chars_to_load",
            None,
            "number of text chars to load from the dataset; int",
            pcheck_not_none,
        ),
        Parameter(
            "drop_prefix",
            None,
            "how many files to drop from the dataset; int",
            pcheck_not_none,
        ),
        Parameter(
            "source_fields_process_fn", None, "lambda for processing source fields; str"
        ),
    ]


FLAGS, _ = mlxu.define_flags_with_default(
    parquet_sample=prepare_config_dict(get_default_parameters(), check_parameters=False)
)


def get_ds_files_urls(hf_dataset: str):
    fs = HfFileSystem()

    files = fs.ls(hf_dataset, detail=False)

    return files


def save_dicts(
    urls,
    source_field,
    writer: DatasetWriter,
    fields_to_retain: List[str],
    source_fields_process_fn,
):
    LOGGER.info(f"In addition to text will retain fields {fields_to_retain}")
    urls = [*urls]
    random.shuffle(urls)
    done = False
    fs = HfFileSystem()
    used_urls = []
    for url in urls:
        used_urls.append(url)
        LOGGER.info(f"Processing {url}")

        with fs.open(url) as f:
            raw_data = f.read()
            file = io.BytesIO(raw_data)
        table = pq.read_table(file)

        table = table.to_pandas().to_dict()

        data_tuples = [table[source_field].values()]
        for ftr in fields_to_retain:
            data_tuples.append(table[ftr].values())

        data_tuples = zip(*data_tuples)

        for rdata in data_tuples:
            to_save = {}
            to_save["text"] = source_fields_process_fn(rdata[0])
            for ftr_k, ftr_v in zip(fields_to_retain, rdata[1:]):
                to_save[ftr_k] = ftr_v
            writer.add(to_save)
            if writer.is_full():
                done = True
                break

        if done == True:
            break
        writer.flush()
    return used_urls


def prepare_dataset(
    dataset: str,
    source_field: str,
    save_path: str,
    num_chars_to_load: int,
    drop_prefix: int = 0,
    fields_to_retain: List[str] = [],
    source_fields_process_fn: Optional[str] = None,
):
    LOGGER.info(f"Gathering info about files from {dataset}")
    remote_files = get_ds_files_urls(hf_dataset=dataset)
    LOGGER.info(
        f"Got {len(remote_files)} files from {dataset}, truncating to {drop_prefix}"
    )
    remote_files = remote_files[drop_prefix:]
    LOGGER.info(f"Those files are {remote_files}")

    LOGGER.info(f"Creating writer {save_path} for {num_chars_to_load} chars")

    if source_fields_process_fn is None:
        source_fields_process_fn = lambda x: x
    else:
        source_fields_process_fn = eval(source_fields_process_fn)

    with DatasetWriter(save_path, num_chars_to_load, add_time_stamp=False) as writer:
        used_urls = save_dicts(
            remote_files,
            source_field,
            writer,
            fields_to_retain=fields_to_retain,
            source_fields_process_fn=source_fields_process_fn,
        )
    return used_urls


def main(_):
    check_config(FLAGS.parquet_sample, get_default_parameters())
    used_urls = prepare_dataset(
        dataset=FLAGS.parquet_sample.dataset,
        source_field=FLAGS.parquet_sample.source_field,
        save_path=FLAGS.parquet_sample.destination_path,
        num_chars_to_load=FLAGS.parquet_sample.num_chars_to_load,
        drop_prefix=FLAGS.parquet_sample.drop_prefix,
        source_fields_process_fn=FLAGS.parquet_sample.source_fields_process_fn,
    )

    dump_parameters(
        FLAGS.parquet_sample,
        get_default_parameters(),
        FLAGS.parquet_sample.destination_path + ".meta.json",
        param_add_prefix="parquet_sample.",
        additional_data={"used_urls": used_urls},
    )


if __name__ == "__main__":
    app.run(main)
